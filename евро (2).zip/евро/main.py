import discord
from discord.ext import commands
from discord import ui
from datetime import datetime, timedelta, timezone
from collections import defaultdict
import asyncio
import re
import json
import os

# ========================= НАСТРОЙКИ =========================
TOKEN = "MTQ4OTkyNDMyMTQzMzM1NDMwMQ.GSO8PV.pOsOvcdRuu638TjJFbQZJ8tbU-ukY_TStzdHiU"
OWNER_ID = 948195128319832155
RAID_MODE = True
WHITELIST_ROLE_IDS = []
ADMIN_ROLE_IDS = []
LOG_CHANNEL_ID = 1498362028689981440
INVITE_LOG_CHANNEL_ID = 1496175127539220570
ROLE_REQUEST_CHANNEL_ID = 0
ROLE_APPROVE_CHANNEL_ID = 1498410423433691176
ALLOWED_LINK_CHANNELS = []
WHITELIST_USERS = []
WHITELIST_BOTS = []
PROTA_USERS = []
PROTA_ROLE_NAME = "Прота"
BACKUP_FOLDER = "backups"
KICKED_NUKERS = set()
role_requests = {}

AUTO_BACKUP_INTERVAL = 1800
auto_backup_enabled = True
last_backup_data = {}

GENERAL_REQUEST_CHANNEL_ID = 0
GENERAL_APPROVE_CHANNEL_ID = 0
REQUEST_LOG_CHANNEL_ID = 0
general_requests = {}

# ========================= WELCOME НАСТРОЙКИ =========================
WELCOME_ENABLED = True
WELCOME_CHANNEL_ID = 0
WELCOME_TEXT = "Добро пожаловать на сервер **{server}**, {user}! 🎉\nТы **{membercount}**-й участник!"
WELCOME_GIF_URL = ""
WELCOME_COLOR = 0x5865F2
WELCOME_TITLE = "👋 Новый участник!"

BANNED_PHRASES = [
    "набор в клан", "набор в", "переезд в", "переезжайте в",
    "переходите в", "вступайте в", "заходите в", "приглашаем в",
    "набираем в", "рекрутинг", "recruitment", "join our", "join my",
]
ALLOWED_DOMAINS = [
    "youtube.com", "youtu.be", "www.youtube.com", "m.youtube.com",
    "tiktok.com", "www.tiktok.com", "vm.tiktok.com", "vt.tiktok.com",
    "twitch.tv", "www.twitch.tv", "clips.twitch.tv",
]

WHITELIST_LINK_LIMIT = 5
WHITELIST_LINK_TIME = 600

ANTI_CHANNEL_SPAM_ENABLED = True
MAX_CHANNELS_CREATED_PER_MINUTE = 3
CHANNEL_SPAM_PUNISHMENT_DURATION = 60

ANTI_CHANNEL_DELETE_ENABLED = True
MAX_CHANNELS_DELETED_PER_MINUTE = 2
CHANNEL_DELETE_PUNISHMENT_DURATION = 120

AUTO_ROLE_ID = 0
AUTO_NICK_ENABLED = True
AUTO_NICK_PREFIX = "AF "

# ========================= АНТИНЮК НАСТРОЙКИ =========================
ANTINUKE_WINDOW = 10
BOT_CHANNEL_DELETE_LIMIT = 1
BOT_CHANNEL_CREATE_LIMIT = 2
BOT_ROLE_DELETE_LIMIT = 1
BOT_ROLE_CREATE_LIMIT = 2
BOT_BAN_LIMIT = 2
BOT_KICK_LIMIT = 3
BOT_ROLE_UPDATE_LIMIT = 3
BOT_WEBHOOK_LIMIT = 1
USER_CHANNEL_DELETE_LIMIT = 2
USER_CHANNEL_CREATE_LIMIT = 3
USER_ROLE_DELETE_LIMIT = 2
USER_ROLE_CREATE_LIMIT = 3
USER_BAN_LIMIT = 3
USER_KICK_LIMIT = 4
USER_ROLE_UPDATE_LIMIT = 5
USER_WEBHOOK_LIMIT = 2

# ========================= ФАЙЛ НАСТРОЕК =========================
SETTINGS_FILE = "bot_settings.json"


def load_settings():
    global RAID_MODE, WHITELIST_USERS, WHITELIST_BOTS, PROTA_USERS
    global ALLOWED_LINK_CHANNELS, ALLOWED_DOMAINS, BANNED_PHRASES
    global LOG_CHANNEL_ID, INVITE_LOG_CHANNEL_ID, ROLE_REQUEST_CHANNEL_ID
    global ROLE_APPROVE_CHANNEL_ID, GENERAL_REQUEST_CHANNEL_ID
    global GENERAL_APPROVE_CHANNEL_ID, REQUEST_LOG_CHANNEL_ID
    global AUTO_ROLE_ID, AUTO_NICK_ENABLED, AUTO_NICK_PREFIX
    global auto_backup_enabled, ANTI_CHANNEL_SPAM_ENABLED
    global ANTI_CHANNEL_DELETE_ENABLED, WHITELIST_ROLE_IDS, ADMIN_ROLE_IDS
    global WELCOME_ENABLED, WELCOME_CHANNEL_ID, WELCOME_TEXT
    global WELCOME_GIF_URL, WELCOME_COLOR, WELCOME_TITLE

    if not os.path.exists(SETTINGS_FILE):
        save_settings()
        return
    try:
        with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        RAID_MODE = data.get("raid_mode", RAID_MODE)
        auto_backup_enabled = data.get("auto_backup_enabled", auto_backup_enabled)
        ANTI_CHANNEL_SPAM_ENABLED = data.get("anti_channel_spam", ANTI_CHANNEL_SPAM_ENABLED)
        ANTI_CHANNEL_DELETE_ENABLED = data.get("anti_channel_delete", ANTI_CHANNEL_DELETE_ENABLED)
        AUTO_NICK_ENABLED = data.get("auto_nick_enabled", AUTO_NICK_ENABLED)
        AUTO_NICK_PREFIX = data.get("auto_nick_prefix", AUTO_NICK_PREFIX)
        AUTO_ROLE_ID = data.get("auto_role_id", AUTO_ROLE_ID)
        LOG_CHANNEL_ID = data.get("log_channel_id", LOG_CHANNEL_ID)
        INVITE_LOG_CHANNEL_ID = data.get("invite_log_channel_id", INVITE_LOG_CHANNEL_ID)
        ROLE_REQUEST_CHANNEL_ID = data.get("role_request_channel_id", ROLE_REQUEST_CHANNEL_ID)
        ROLE_APPROVE_CHANNEL_ID = data.get("role_approve_channel_id", ROLE_APPROVE_CHANNEL_ID)
        GENERAL_REQUEST_CHANNEL_ID = data.get("general_request_channel_id", GENERAL_REQUEST_CHANNEL_ID)
        GENERAL_APPROVE_CHANNEL_ID = data.get("general_approve_channel_id", GENERAL_APPROVE_CHANNEL_ID)
        REQUEST_LOG_CHANNEL_ID = data.get("request_log_channel_id", REQUEST_LOG_CHANNEL_ID)
        WHITELIST_USERS.clear(); WHITELIST_USERS.extend(data.get("whitelist_users", []))
        WHITELIST_BOTS.clear(); WHITELIST_BOTS.extend(data.get("whitelist_bots", []))
        PROTA_USERS.clear(); PROTA_USERS.extend(data.get("prota_users", []))
        ALLOWED_LINK_CHANNELS.clear(); ALLOWED_LINK_CHANNELS.extend(data.get("allowed_link_channels", []))
        WHITELIST_ROLE_IDS.clear(); WHITELIST_ROLE_IDS.extend(data.get("whitelist_role_ids", []))
        ADMIN_ROLE_IDS.clear(); ADMIN_ROLE_IDS.extend(data.get("admin_role_ids", []))
        if "allowed_domains" in data:
            ALLOWED_DOMAINS.clear(); ALLOWED_DOMAINS.extend(data["allowed_domains"])
        if "banned_phrases" in data:
            BANNED_PHRASES.clear(); BANNED_PHRASES.extend(data["banned_phrases"])
        WELCOME_ENABLED = data.get("welcome_enabled", WELCOME_ENABLED)
        WELCOME_CHANNEL_ID = data.get("welcome_channel_id", WELCOME_CHANNEL_ID)
        WELCOME_TEXT = data.get("welcome_text", WELCOME_TEXT)
        WELCOME_GIF_URL = data.get("welcome_gif_url", WELCOME_GIF_URL)
        WELCOME_COLOR = data.get("welcome_color", WELCOME_COLOR)
        WELCOME_TITLE = data.get("welcome_title", WELCOME_TITLE)
        print(f"[SETTINGS] ✅ Загружено | Прота: {len(PROTA_USERS)} | WL: {len(WHITELIST_USERS)}")
    except Exception as e:
        print(f"[SETTINGS] ❌ Ошибка: {e}")


def save_settings():
    try:
        data = {
            "raid_mode": RAID_MODE, "auto_backup_enabled": auto_backup_enabled,
            "anti_channel_spam": ANTI_CHANNEL_SPAM_ENABLED,
            "anti_channel_delete": ANTI_CHANNEL_DELETE_ENABLED,
            "auto_nick_enabled": AUTO_NICK_ENABLED, "auto_nick_prefix": AUTO_NICK_PREFIX,
            "auto_role_id": AUTO_ROLE_ID, "log_channel_id": LOG_CHANNEL_ID,
            "invite_log_channel_id": INVITE_LOG_CHANNEL_ID,
            "role_request_channel_id": ROLE_REQUEST_CHANNEL_ID,
            "role_approve_channel_id": ROLE_APPROVE_CHANNEL_ID,
            "general_request_channel_id": GENERAL_REQUEST_CHANNEL_ID,
            "general_approve_channel_id": GENERAL_APPROVE_CHANNEL_ID,
            "request_log_channel_id": REQUEST_LOG_CHANNEL_ID,
            "whitelist_users": list(WHITELIST_USERS),
            "whitelist_bots": list(WHITELIST_BOTS),
            "prota_users": list(PROTA_USERS),
            "allowed_link_channels": list(ALLOWED_LINK_CHANNELS),
            "whitelist_role_ids": list(WHITELIST_ROLE_IDS),
            "admin_role_ids": list(ADMIN_ROLE_IDS),
            "allowed_domains": list(ALLOWED_DOMAINS),
            "banned_phrases": list(BANNED_PHRASES),
            "welcome_enabled": WELCOME_ENABLED,
            "welcome_channel_id": WELCOME_CHANNEL_ID,
            "welcome_text": WELCOME_TEXT,
            "welcome_gif_url": WELCOME_GIF_URL,
            "welcome_color": WELCOME_COLOR,
            "welcome_title": WELCOME_TITLE,
            "last_saved": str(datetime.now(timezone.utc))
        }
        with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[SETTINGS] ❌ Ошибка сохранения: {e}")


load_settings()

# ========================= БОТ ===============================
intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True
intents.invites = True
intents.voice_states = True
intents.reactions = True

bot = commands.Bot(command_prefix=".", intents=intents, help_command=None)
message_tracker = defaultdict(list)
invite_cache = {}
whitelist_link_tracker = defaultdict(list)
voice_tracker = {}

LINK_PATTERN = re.compile(
    r"(https?://|www\.|discord\.gg/|discord\.com/invite/)"
    r"[-\w._~:/?#\[\]@!$&'()*+,;=%]+",
    re.IGNORECASE
)

# ========================= УТИЛИТЫ ПРИВЕТСТВИЙ =========================
def format_welcome(text, member):
    if not text: return ""
    return text.replace("{user}", member.mention) \
               .replace("{user.name}", member.name) \
               .replace("{user.id}", str(member.id)) \
               .replace("{server}", member.guild.name) \
               .replace("{membercount}", str(member.guild.member_count)) \
               .replace("{nl}", "\n")

# ========================= АНТИНЮК ТРЕКЕР =========================
nuke_tracker = defaultdict(lambda: defaultdict(lambda: defaultdict(list)))
punished_nukers = set()
deleted_channels_cache = defaultdict(list)
deleted_roles_cache = defaultdict(list)


def clean_nuke_tracker(guild_id, user_id):
    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(seconds=ANTINUKE_WINDOW)
    for action_type in list(nuke_tracker[guild_id][user_id].keys()):
        nuke_tracker[guild_id][user_id][action_type] = [
            t for t in nuke_tracker[guild_id][user_id][action_type] if t > cutoff
        ]
        if not nuke_tracker[guild_id][user_id][action_type]:
            del nuke_tracker[guild_id][user_id][action_type]


def track_action(guild_id, user_id, action_type):
    now = datetime.now(timezone.utc)
    nuke_tracker[guild_id][user_id][action_type].append(now)
    clean_nuke_tracker(guild_id, user_id)
    return len(nuke_tracker[guild_id][user_id][action_type])


def is_over_limit(count, is_bot, action_type):
    limits = {
        "channel_delete": (BOT_CHANNEL_DELETE_LIMIT, USER_CHANNEL_DELETE_LIMIT),
        "channel_create": (BOT_CHANNEL_CREATE_LIMIT, USER_CHANNEL_CREATE_LIMIT),
        "role_delete": (BOT_ROLE_DELETE_LIMIT, USER_ROLE_DELETE_LIMIT),
        "role_create": (BOT_ROLE_CREATE_LIMIT, USER_ROLE_CREATE_LIMIT),
        "ban": (BOT_BAN_LIMIT, USER_BAN_LIMIT),
        "kick": (BOT_KICK_LIMIT, USER_KICK_LIMIT),
        "role_update": (BOT_ROLE_UPDATE_LIMIT, USER_ROLE_UPDATE_LIMIT),
        "webhook": (BOT_WEBHOOK_LIMIT, USER_WEBHOOK_LIMIT),
    }
    bot_limit, user_limit = limits.get(action_type, (2, 3))
    return count >= (bot_limit if is_bot else user_limit)


async def punish_nuker(guild, user, action_type, count, is_bot_user):
    key = f"{guild.id}_{user.id}"
    if key in punished_nukers:
        return
    punished_nukers.add(key)
    now = datetime.now(timezone.utc)
    member = guild.get_member(user.id)
    try:
        await create_backup(guild, reason=f"antinuke_{user.id}")
    except:
        pass
    action_labels = {
        "channel_delete": "удаление каналов", "channel_create": "создание каналов",
        "role_delete": "удаление ролей", "role_create": "создание ролей",
        "ban": "массовый бан", "kick": "массовый кик",
        "role_update": "изменение ролей", "webhook": "создание вебхуков",
    }
    label = action_labels.get(action_type, action_type)
    if is_bot_user:
        try:
            if member:
                try:
                    removable = [r for r in member.roles if not r.is_default() and not r.managed and r < guild.me.top_role]
                    if removable:
                        await member.remove_roles(*removable, reason="АНТИНЮК")
                except:
                    pass
                await asyncio.sleep(0.2)
                await member.ban(reason=f"АНТИНЮК: бот-нюкер ({label} x{count})")
            e = discord.Embed(title="🚨 БОТ-НЮКЕР ЗАБАНЕН", color=0xff0000, timestamp=now)
            e.add_field(name="Бот", value=f"{user} (`{user.id}`)")
            e.add_field(name="Действие", value=f"{label} x{count} за {ANTINUKE_WINDOW}с")
            await send_log(guild, e)
        except discord.Forbidden:
            try:
                if member:
                    removable = [r for r in member.roles if not r.is_default() and not r.managed and r < guild.me.top_role]
                    if removable:
                        await member.remove_roles(*removable, reason="АНТИНЮК: снятие прав")
            except:
                pass
            e = discord.Embed(title="⚠️ НЕ УДАЛОСЬ ЗАБАНИТЬ НЮКЕРА", color=0xff0000, timestamp=now)
            e.description = f"**{user} (`{user.id}`) — НЮКЕР! ЗАБАНЬТЕ ВРУЧНУЮ!**"
            await send_log(guild, e)
        except Exception as ex:
            print(f"[ANTINUKE] Ошибка: {ex}")
    else:
        try:
            if member:
                try:
                    removable = [r for r in member.roles if not r.is_default() and not r.managed and r < guild.me.top_role]
                    if removable:
                        await member.remove_roles(*removable, reason="АНТИНЮК")
                except:
                    pass
                await asyncio.sleep(0.2)
                await member.timeout(timedelta(days=28), reason=f"АНТИНЮК: {label} x{count}")
            if user.id in WHITELIST_USERS: WHITELIST_USERS.remove(user.id)
            if user.id in PROTA_USERS: PROTA_USERS.remove(user.id)
            save_settings()
            e = discord.Embed(title="🚨 НЮКЕР ОСТАНОВЛЕН", color=0xff0000, timestamp=now)
            e.add_field(name="Пользователь", value=f"{user} (`{user.id}`)")
            e.add_field(name="Действие", value=f"{label} x{count} за {ANTINUKE_WINDOW}с")
            e.add_field(name="Наказание", value="Таймаут 28 дней + снятие ролей")
            await send_log(guild, e)
        except Exception as ex:
            print(f"[ANTINUKE] Ошибка: {ex}")


async def check_and_punish(guild, user_id, action_type):
    if not RAID_MODE:
        return False
    guild_obj = guild if isinstance(guild, discord.Guild) else bot.get_guild(guild)
    if not guild_obj:
        return False
    member = guild_obj.get_member(user_id)
    if not member:
        return False
    if user_id == bot.user.id:
        return False
    if user_id == OWNER_ID or user_id == guild_obj.owner_id:
        return False
    is_bot_user = member.bot
    if is_bot_user:
        if is_bot_whitelisted(member):
            return False
    else:
        if is_prota_user(user_id) or is_whitelisted(member):
            return False
    if f"{guild_obj.id}_{user_id}" in punished_nukers:
        return True
    count = track_action(guild_obj.id, user_id, action_type)
    if is_over_limit(count, is_bot_user, action_type):
        await punish_nuker(guild_obj, member, action_type, count, is_bot_user)
        return True
    return False


# ========================= УТИЛИТЫ ===========================
def is_owner(ctx_or_id):
    if isinstance(ctx_or_id, int): return ctx_or_id == OWNER_ID
    if isinstance(ctx_or_id, commands.Context): return ctx_or_id.author.id == OWNER_ID
    return False


def is_whitelisted(member: discord.Member) -> bool:
    if member.guild_permissions.administrator: return True
    if member.id in WHITELIST_USERS: return True
    if member.id in PROTA_USERS: return True
    return any(role.id in WHITELIST_ROLE_IDS + ADMIN_ROLE_IDS for role in member.roles)


def is_whitelist_user(member: discord.Member) -> bool:
    return member.id in WHITELIST_USERS or member.id in PROTA_USERS


def is_prota_user(user_id: int) -> bool:
    return user_id in PROTA_USERS


def is_verified_bot(member: discord.Member) -> bool:
    if not member.bot: return False
    try:
        if member.public_flags.verified_bot: return True
    except:
        pass
    return False


def is_bot_whitelisted(bot_member: discord.Member) -> bool:
    if bot_member.id in WHITELIST_BOTS: return True
    if is_verified_bot(bot_member): return True
    return False


def contains_banned_phrase(text: str):
    text_lower = text.lower()
    for phrase in BANNED_PHRASES:
        if phrase.lower() in text_lower: return phrase
    return None


async def send_log(guild: discord.Guild, embed: discord.Embed):
    channel = guild.get_channel(LOG_CHANNEL_ID)
    if channel:
        try:
            await channel.send(embed=embed)
        except:
            pass


async def send_invite_log(guild: discord.Guild, embed: discord.Embed):
    channel = guild.get_channel(INVITE_LOG_CHANNEL_ID)
    if channel:
        try:
            await channel.send(embed=embed)
        except:
            pass


async def get_invites(guild: discord.Guild):
    try:
        invites = await guild.invites()
        return {invite.code: invite for invite in invites}
    except:
        return {}


async def owner_check(ctx) -> bool:
    if ctx.author.id == OWNER_ID: return True
    await ctx.send(embed=discord.Embed(
        title="❌ Нет доступа", description=f"ID: {ctx.author.id}", color=0xff0000
    ))
    return False


async def protection_check(ctx) -> bool:
    if ctx.author.id == OWNER_ID: return True
    if ctx.author.id in PROTA_USERS: return True
    await ctx.send(embed=discord.Embed(
        title="❌ Доступ запрещён", description="Только владелец или Прота.", color=0xff0000
    ), delete_after=5)
    return False


# ========================= СИСТЕМА БЭКАПОВ ===================
async def create_backup(guild: discord.Guild, reason: str = "manual") -> dict:
    now = datetime.now(timezone.utc)
    backup_data = {
        "guild_name": guild.name, "guild_id": guild.id,
        "created_at": str(now), "reason": reason,
        "roles": [], "categories": [],
        "text_channels": [], "voice_channels": [],
        "stage_channels": [], "forum_channels": []
    }
    for role in sorted(guild.roles, key=lambda r: r.position):
        if role.is_default() or role.managed:
            continue
        backup_data["roles"].append({
            "name": role.name, "id": role.id, "color": role.color.value,
            "hoist": role.hoist, "mentionable": role.mentionable,
            "permissions": role.permissions.value, "position": role.position
        })
    for cat in sorted(guild.categories, key=lambda c: c.position):
        ovs = []
        for target, ow in cat.overwrites.items():
            allow, deny = ow.pair()
            ovs.append({
                "id": target.id,
                "type": "role" if isinstance(target, discord.Role) else "member",
                "allow": allow.value, "deny": deny.value
            })
        backup_data["categories"].append({
            "name": cat.name, "id": cat.id, "position": cat.position, "overwrites": ovs
        })
    for ch in sorted(guild.text_channels, key=lambda c: (c.category.position if c.category else -1, c.position)):
        ovs = []
        for target, ow in ch.overwrites.items():
            allow, deny = ow.pair()
            ovs.append({
                "id": target.id,
                "type": "role" if isinstance(target, discord.Role) else "member",
                "allow": allow.value, "deny": deny.value
            })
        backup_data["text_channels"].append({
            "name": ch.name, "id": ch.id, "topic": ch.topic,
            "slowmode": ch.slowmode_delay, "nsfw": ch.is_nsfw(),
            "category_id": ch.category_id,
            "category_name": ch.category.name if ch.category else None,
            "position": ch.position, "overwrites": ovs
        })
    for ch in sorted(guild.voice_channels, key=lambda c: (c.category.position if c.category else -1, c.position)):
        ovs = []
        for target, ow in ch.overwrites.items():
            allow, deny = ow.pair()
            ovs.append({
                "id": target.id,
                "type": "role" if isinstance(target, discord.Role) else "member",
                "allow": allow.value, "deny": deny.value
            })
        backup_data["voice_channels"].append({
            "name": ch.name, "id": ch.id, "bitrate": ch.bitrate,
            "user_limit": ch.user_limit, "category_id": ch.category_id,
            "category_name": ch.category.name if ch.category else None,
            "position": ch.position, "overwrites": ovs
        })
    last_backup_data[guild.id] = backup_data
    if not os.path.exists(BACKUP_FOLDER):
        os.makedirs(BACKUP_FOLDER)
    fn = f"{BACKUP_FOLDER}/backup_{guild.id}_{now.strftime('%Y%m%d%H%M%S')}_{reason}.json"
    with open(fn, "w", encoding="utf-8") as f:
        json.dump(backup_data, f, ensure_ascii=False, indent=2)
    return backup_data


async def full_restore_backup(guild: discord.Guild, data: dict, status_msg=None) -> dict:
    result = {
        "roles_created": [], "roles_updated": [], "roles_errors": [],
        "categories_created": [], "categories_updated": [], "cat_errors": [],
        "text_created": [], "text_updated": [], "text_errors": [],
        "voice_created": [], "voice_updated": [], "voice_errors": [],
        "channels_deleted": []
    }

    async def update_status(text):
        if status_msg:
            try:
                await status_msg.edit(content=text)
            except:
                pass
        print(f"[RESTORE] {text}")

    await update_status("🔄 **Шаг 1/6:** Восстановление ролей...")
    role_id_map = {}
    for role_data in sorted(data.get("roles", []), key=lambda r: r["position"]):
        try:
            existing = discord.utils.get(guild.roles, name=role_data["name"])
            if existing:
                try:
                    await existing.edit(
                        color=discord.Color(role_data.get("color", 0)),
                        hoist=role_data.get("hoist", False),
                        mentionable=role_data.get("mentionable", False),
                        permissions=discord.Permissions(role_data.get("permissions", 0)),
                        reason="Восстановление бэкапа"
                    )
                    role_id_map[role_data["id"]] = existing
                    result["roles_updated"].append(existing.name)
                except discord.Forbidden:
                    role_id_map[role_data["id"]] = existing
            else:
                new_role = await guild.create_role(
                    name=role_data["name"],
                    color=discord.Color(role_data.get("color", 0)),
                    hoist=role_data.get("hoist", False),
                    mentionable=role_data.get("mentionable", False),
                    permissions=discord.Permissions(role_data.get("permissions", 0)),
                    reason="Восстановление бэкапа"
                )
                role_id_map[role_data["id"]] = new_role
                result["roles_created"].append(new_role.name)
                await asyncio.sleep(0.4)
        except Exception as ex:
            result["roles_errors"].append(f"{role_data.get('name')}: {str(ex)[:50]}")

    await update_status("🔄 **Шаг 1/6:** Выставляем позиции ролей...")
    try:
        positions = {}
        for role_data in data.get("roles", []):
            role = role_id_map.get(role_data["id"])
            if not role:
                role = discord.utils.get(guild.roles, name=role_data["name"])
            if role and not role.is_default() and not role.managed:
                pos = max(1, min(role_data["position"], len(guild.roles) - 1))
                positions[role] = pos
        if positions:
            await guild.edit_role_positions(positions=positions, reason="Восстановление позиций ролей")
            await asyncio.sleep(0.5)
    except Exception as ex:
        print(f"[RESTORE] Ошибка позиций ролей: {ex}")

    await update_status("🔄 **Шаг 2/6:** Удаление лишних каналов...")
    backup_channel_names = set()
    for ch in data.get("text_channels", []):
        backup_channel_names.add(ch["name"].lower())
    for ch in data.get("voice_channels", []):
        backup_channel_names.add(ch["name"].lower())
    for cat in data.get("categories", []):
        backup_channel_names.add(cat["name"].lower())
    for ch in list(guild.channels):
        if ch.name.lower() not in backup_channel_names:
            if guild.system_channel and ch.id == guild.system_channel.id:
                continue
            try:
                await ch.delete(reason="Восстановление бэкапа: удаление лишних каналов")
                result["channels_deleted"].append(ch.name)
                await asyncio.sleep(0.3)
            except:
                pass

    await update_status("🔄 **Шаг 3/6:** Восстановление категорий...")
    cat_id_map = {}
    for cat_data in sorted(data.get("categories", []), key=lambda c: c["position"]):
        try:
            overwrites = build_overwrites(guild, cat_data.get("overwrites", []), role_id_map)
            existing_cat = discord.utils.get(guild.categories, name=cat_data["name"])
            if existing_cat:
                try:
                    await existing_cat.edit(overwrites=overwrites, reason="Восстановление бэкапа")
                    cat_id_map[cat_data["id"]] = existing_cat
                    result["categories_updated"].append(existing_cat.name)
                except Exception as ex:
                    cat_id_map[cat_data["id"]] = existing_cat
                    result["cat_errors"].append(f"{cat_data['name']}: {str(ex)[:50]}")
            else:
                new_cat = await guild.create_category(
                    name=cat_data["name"], overwrites=overwrites, reason="Восстановление бэкапа"
                )
                cat_id_map[cat_data["id"]] = new_cat
                result["categories_created"].append(new_cat.name)
                await asyncio.sleep(0.4)
        except Exception as ex:
            result["cat_errors"].append(f"{cat_data.get('name')}: {str(ex)[:50]}")

    await update_status(f"🔄 **Шаг 4/6:** Текстовые каналы ({len(data.get('text_channels', []))} шт.)...")
    for ch_data in sorted(data.get("text_channels", []), key=lambda c: (c.get("position", 0))):
        try:
            overwrites = build_overwrites(guild, ch_data.get("overwrites", []), role_id_map)
            category = None
            if ch_data.get("category_id"):
                category = cat_id_map.get(ch_data["category_id"])
                if not category:
                    category = discord.utils.get(guild.categories, name=ch_data.get("category_name"))
            existing_ch = discord.utils.get(guild.text_channels, name=ch_data["name"])
            if existing_ch:
                try:
                    await existing_ch.edit(
                        topic=ch_data.get("topic"), slowmode_delay=ch_data.get("slowmode", 0),
                        nsfw=ch_data.get("nsfw", False), category=category,
                        overwrites=overwrites, reason="Восстановление бэкапа"
                    )
                    result["text_updated"].append(existing_ch.name)
                except Exception as ex:
                    result["text_errors"].append(f"#{ch_data['name']}: {str(ex)[:50]}")
            else:
                new_ch = await guild.create_text_channel(
                    name=ch_data["name"], topic=ch_data.get("topic"),
                    slowmode_delay=ch_data.get("slowmode", 0), nsfw=ch_data.get("nsfw", False),
                    category=category, overwrites=overwrites, reason="Восстановление бэкапа"
                )
                result["text_created"].append(new_ch.name)
                await asyncio.sleep(0.4)
        except Exception as ex:
            result["text_errors"].append(f"#{ch_data.get('name')}: {str(ex)[:50]}")

    await update_status(f"🔄 **Шаг 5/6:** Голосовые каналы ({len(data.get('voice_channels', []))} шт.)...")
    for ch_data in sorted(data.get("voice_channels", []), key=lambda c: c.get("position", 0)):
        try:
            overwrites = build_overwrites(guild, ch_data.get("overwrites", []), role_id_map)
            category = None
            if ch_data.get("category_id"):
                category = cat_id_map.get(ch_data["category_id"])
                if not category:
                    category = discord.utils.get(guild.categories, name=ch_data.get("category_name"))
            existing_ch = discord.utils.get(guild.voice_channels, name=ch_data["name"])
            if existing_ch:
                try:
                    await existing_ch.edit(
                        bitrate=min(ch_data.get("bitrate", 64000), guild.bitrate_limit),
                        user_limit=ch_data.get("user_limit", 0), category=category,
                        overwrites=overwrites, reason="Восстановление бэкапа"
                    )
                    result["voice_updated"].append(existing_ch.name)
                except Exception as ex:
                    result["voice_errors"].append(f"🔊{ch_data['name']}: {str(ex)[:50]}")
            else:
                new_ch = await guild.create_voice_channel(
                    name=ch_data["name"],
                    bitrate=min(ch_data.get("bitrate", 64000), guild.bitrate_limit),
                    user_limit=ch_data.get("user_limit", 0), category=category,
                    overwrites=overwrites, reason="Восстановление бэкапа"
                )
                result["voice_created"].append(new_ch.name)
                await asyncio.sleep(0.4)
        except Exception as ex:
            result["voice_errors"].append(f"🔊{ch_data.get('name')}: {str(ex)[:50]}")

    await update_status("🔄 **Шаг 6/6:** Восстановление позиций каналов...")
    await restore_channel_positions(guild, data, cat_id_map)
    return result


def build_overwrites(guild, overwrites_data, role_id_map=None):
    overwrites = {}
    for ow_data in overwrites_data:
        target = None
        old_id = ow_data["id"]
        if ow_data["type"] == "role":
            if role_id_map: target = role_id_map.get(old_id)
            if not target: target = guild.get_role(old_id)
            if not target and old_id == guild.id: target = guild.default_role
        else:
            target = guild.get_member(old_id)
        if target:
            try:
                allow = discord.Permissions(ow_data["allow"])
                deny = discord.Permissions(ow_data["deny"])
                overwrites[target] = discord.PermissionOverwrite.from_pair(allow, deny)
            except Exception as ex:
                print(f"[RESTORE] Ошибка overwrite: {ex}")
    return overwrites


async def restore_channel_positions(guild, data, cat_id_map):
    try:
        channel_moves = []
        for ch_data in data.get("text_channels", []):
            ch = discord.utils.get(guild.text_channels, name=ch_data["name"])
            if not ch: continue
            category = cat_id_map.get(ch_data.get("category_id")) or discord.utils.get(guild.categories, name=ch_data.get("category_name"))
            channel_moves.append({"channel": ch, "position": ch_data.get("position", 0), "category": category})
        for ch_data in data.get("voice_channels", []):
            ch = discord.utils.get(guild.voice_channels, name=ch_data["name"])
            if not ch: continue
            category = cat_id_map.get(ch_data.get("category_id")) or discord.utils.get(guild.categories, name=ch_data.get("category_name"))
            channel_moves.append({"channel": ch, "position": ch_data.get("position", 0), "category": category})
        for move in sorted(channel_moves, key=lambda x: x["position"]):
            try:
                await move["channel"].edit(category=move["category"], position=move["position"], reason="Восстановление позиций")
                await asyncio.sleep(0.2)
            except Exception as ex:
                print(f"[RESTORE POS] {move['channel'].name}: {ex}")
    except Exception as ex:
        print(f"[RESTORE POS] Общая ошибка: {ex}")


# ========================= ФОНОВЫЕ ЗАДАЧИ =========================
async def auto_save_settings_task():
    await bot.wait_until_ready()
    while not bot.is_closed():
        await asyncio.sleep(300)
        save_settings()


async def auto_backup_task():
    await bot.wait_until_ready()
    for g in bot.guilds:
        await create_backup(g, reason="startup")
    while not bot.is_closed():
        await asyncio.sleep(AUTO_BACKUP_INTERVAL)
        if not auto_backup_enabled:
            continue
        for g in bot.guilds:
            await create_backup(g, reason="auto")


async def cleanup_old_backups():
    while not bot.is_closed():
        await asyncio.sleep(3600)
        if not os.path.exists(BACKUP_FOLDER):
            continue
        files = sorted(
            [f for f in os.listdir(BACKUP_FOLDER) if f.endswith(".json")],
            key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER, x)), reverse=True
        )
        for old in files[30:]:
            try:
                os.remove(os.path.join(BACKUP_FOLDER, old))
            except:
                pass


async def cleanup_punished():
    while not bot.is_closed():
        await asyncio.sleep(120)
        punished_nukers.clear()


async def cleanup_nuke_tracker():
    while not bot.is_closed():
        await asyncio.sleep(30)
        now = datetime.now(timezone.utc)
        cutoff = now - timedelta(seconds=ANTINUKE_WINDOW * 3)
        for guild_id in list(nuke_tracker.keys()):
            for user_id in list(nuke_tracker[guild_id].keys()):
                for action in list(nuke_tracker[guild_id][user_id].keys()):
                    nuke_tracker[guild_id][user_id][action] = [
                        t for t in nuke_tracker[guild_id][user_id][action] if t > cutoff
                    ]
                    if not nuke_tracker[guild_id][user_id][action]:
                        del nuke_tracker[guild_id][user_id][action]
                if not nuke_tracker[guild_id][user_id]:
                    del nuke_tracker[guild_id][user_id]


# ========================= АНТИНЮК СОБЫТИЯ =========================
@bot.event
async def on_guild_channel_delete(channel):
    guild = channel.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    channel_data = {
        "name": channel.name,
        "type": "text" if isinstance(channel, discord.TextChannel) else (
            "voice" if isinstance(channel, discord.VoiceChannel) else "category"),
        "category_id": getattr(channel, 'category_id', None),
        "category_name": channel.category.name if hasattr(channel, 'category') and channel.category else None,
        "position": channel.position, "overwrites": [],
        "topic": getattr(channel, 'topic', None),
        "slowmode_delay": getattr(channel, 'slowmode_delay', 0),
        "nsfw": getattr(channel, 'is_nsfw', lambda: False)(),
        "bitrate": getattr(channel, 'bitrate', 64000),
        "user_limit": getattr(channel, 'user_limit', 0),
        "deleted_at": now
    }
    for target, overwrite in channel.overwrites.items():
        allow, deny = overwrite.pair()
        channel_data["overwrites"].append({
            "target_id": target.id,
            "target_type": "role" if isinstance(target, discord.Role) else "member",
            "allow": allow.value, "deny": deny.value
        })
    deleted_channels_cache[guild.id].append(channel_data)
    if len(deleted_channels_cache[guild.id]) > 50:
        deleted_channels_cache[guild.id] = deleted_channels_cache[guild.id][-50:]
    deleter = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.channel_delete):
            if entry.target.id == channel.id and (now - entry.created_at).total_seconds() < 10:
                deleter = entry.user
                break
    except:
        pass
    if not deleter: return
    was_punished = await check_and_punish(guild, deleter.id, "channel_delete")
    if was_punished:
        await restore_deleted_channels(guild, deleter.id)


@bot.event
async def on_guild_channel_create(channel):
    guild = channel.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    creator = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.channel_create):
            if entry.target.id == channel.id and (now - entry.created_at).total_seconds() < 10:
                creator = entry.user
                break
    except:
        pass
    if not creator: return
    was_punished = await check_and_punish(guild, creator.id, "channel_create")
    if was_punished:
        await delete_nuker_channels(guild, creator.id)


@bot.event
async def on_guild_role_delete(role):
    guild = role.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    role_data = {
        "name": role.name, "id": role.id, "color": role.color.value,
        "hoist": role.hoist, "mentionable": role.mentionable,
        "permissions": role.permissions.value, "position": role.position,
        "deleted_at": now
    }
    deleted_roles_cache[guild.id].append(role_data)
    if len(deleted_roles_cache[guild.id]) > 30:
        deleted_roles_cache[guild.id] = deleted_roles_cache[guild.id][-30:]
    deleter = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.role_delete):
            if entry.target.id == role.id and (now - entry.created_at).total_seconds() < 10:
                deleter = entry.user
                break
    except:
        pass
    if not deleter: return
    was_punished = await check_and_punish(guild, deleter.id, "role_delete")
    if was_punished:
        await restore_deleted_roles(guild)


@bot.event
async def on_guild_role_create(role):
    guild = role.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    creator = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.role_create):
            if entry.target.id == role.id and (now - entry.created_at).total_seconds() < 10:
                creator = entry.user
                break
    except:
        pass
    if not creator: return
    await check_and_punish(guild, creator.id, "role_create")


@bot.event
async def on_guild_role_update(before, after):
    guild = after.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    dangerous_perms = [
        'administrator', 'ban_members', 'kick_members',
        'manage_channels', 'manage_guild', 'manage_roles',
        'manage_webhooks', 'mention_everyone'
    ]
    added_dangerous = any(
        not getattr(before.permissions, p) and getattr(after.permissions, p)
        for p in dangerous_perms
    )
    if not added_dangerous: return
    updater = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.role_update):
            if entry.target.id == after.id and (now - entry.created_at).total_seconds() < 10:
                updater = entry.user
                break
    except:
        pass
    if not updater: return
    was_punished = await check_and_punish(guild, updater.id, "role_update")
    if was_punished:
        try:
            await after.edit(permissions=before.permissions, reason="АНТИНЮК: откат прав")
        except:
            pass


@bot.event
async def on_member_ban(guild, user):
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    banner = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.ban):
            if entry.target.id == user.id and (now - entry.created_at).total_seconds() < 10:
                banner = entry.user
                break
    except:
        pass
    if not banner: return
    was_punished = await check_and_punish(guild, banner.id, "ban")
    if was_punished:
        await unban_nuker_victims(guild, banner.id)


@bot.event
async def on_webhooks_update(channel):
    guild = channel.guild
    if not RAID_MODE: return
    now = datetime.now(timezone.utc)
    creator = None
    try:
        await asyncio.sleep(0.3)
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.webhook_create):
            if (now - entry.created_at).total_seconds() < 10:
                creator = entry.user
                break
    except:
        pass
    if not creator: return
    was_punished = await check_and_punish(guild, creator.id, "webhook")
    if was_punished:
        try:
            webhooks = await guild.webhooks()
            for wh in webhooks:
                if wh.user and wh.user.id == creator.id:
                    try:
                        await wh.delete(reason="АНТИНЮК")
                    except:
                        pass
        except:
            pass


# ========================= ВОССТАНОВЛЕНИЕ =========================
async def restore_deleted_channels(guild, nuker_id):
    now = datetime.now(timezone.utc)
    restored = []
    recent = [
        ch for ch in deleted_channels_cache.get(guild.id, [])
        if (now - ch["deleted_at"]).total_seconds() < 60
    ]
    for ch_data in recent:
        try:
            category = discord.utils.get(guild.categories, id=ch_data.get("category_id")) if ch_data.get("category_id") else None
            if not category and ch_data.get("category_name"):
                category = discord.utils.get(guild.categories, name=ch_data["category_name"])
            overwrites = {}
            for ow in ch_data.get("overwrites", []):
                target = guild.get_role(ow["target_id"]) if ow["target_type"] == "role" else guild.get_member(ow["target_id"])
                if not target and ow["target_id"] == guild.id: target = guild.default_role
                if target:
                    overwrites[target] = discord.PermissionOverwrite.from_pair(
                        discord.Permissions(ow["allow"]), discord.Permissions(ow["deny"])
                    )
            if ch_data["type"] == "text":
                new_ch = await guild.create_text_channel(
                    name=ch_data["name"], category=category, topic=ch_data.get("topic"),
                    slowmode_delay=ch_data.get("slowmode_delay", 0), nsfw=ch_data.get("nsfw", False),
                    overwrites=overwrites, reason="АНТИНЮК: восстановление"
                )
                restored.append(f"#{new_ch.name}")
            elif ch_data["type"] == "voice":
                new_ch = await guild.create_voice_channel(
                    name=ch_data["name"], category=category,
                    bitrate=min(ch_data.get("bitrate", 64000), guild.bitrate_limit),
                    user_limit=ch_data.get("user_limit", 0),
                    overwrites=overwrites, reason="АНТИНЮК: восстановление"
                )
                restored.append(f"🔊{new_ch.name}")
            await asyncio.sleep(0.4)
        except Exception as ex:
            print(f"[RESTORE] Ошибка: {ex}")
    if restored:
        e = discord.Embed(title="🔄 Каналы восстановлены", description="\n".join(restored), color=0x00ff00)
        await send_log(guild, e)
    deleted_channels_cache[guild.id] = [
        ch for ch in deleted_channels_cache[guild.id]
        if (now - ch["deleted_at"]).total_seconds() > 60
    ]


async def restore_deleted_roles(guild):
    now = datetime.now(timezone.utc)
    restored = []
    recent = [
        r for r in deleted_roles_cache.get(guild.id, [])
        if (now - r["deleted_at"]).total_seconds() < 60
    ]
    for role_data in recent:
        try:
            existing = discord.utils.get(guild.roles, name=role_data["name"])
            if existing: continue
            new_role = await guild.create_role(
                name=role_data["name"], color=discord.Color(role_data.get("color", 0)),
                hoist=role_data.get("hoist", False), mentionable=role_data.get("mentionable", False),
                permissions=discord.Permissions(role_data.get("permissions", 0)),
                reason="АНТИНЮК: восстановление роли"
            )
            restored.append(new_role.name)
            await asyncio.sleep(0.5)
        except Exception as ex:
            print(f"[RESTORE ROLE] Ошибка: {ex}")
    if restored:
        e = discord.Embed(title="🔄 Роли восстановлены", description="\n".join(restored), color=0x00ff00)
        await send_log(guild, e)
    deleted_roles_cache[guild.id] = [
        r for r in deleted_roles_cache[guild.id]
        if (now - r["deleted_at"]).total_seconds() > 60
    ]


async def delete_nuker_channels(guild, nuker_id):
    now = datetime.now(timezone.utc)
    try:
        async for entry in guild.audit_logs(limit=30, action=discord.AuditLogAction.channel_create):
            if entry.user.id == nuker_id and (now - entry.created_at).total_seconds() < 60:
                ch = guild.get_channel(entry.target.id)
                if ch:
                    try:
                        await ch.delete(reason="АНТИНЮК: удаление каналов нюкера")
                    except:
                        pass
    except:
        pass


async def unban_nuker_victims(guild, nuker_id):
    now = datetime.now(timezone.utc)
    unbanned = []
    try:
        async for entry in guild.audit_logs(limit=30, action=discord.AuditLogAction.ban):
            if entry.user.id == nuker_id and (now - entry.created_at).total_seconds() < 60:
                try:
                    await guild.unban(entry.target, reason="АНТИНЮК: разбан жертв")
                    unbanned.append(str(entry.target))
                    await asyncio.sleep(0.3)
                except:
                    pass
    except:
        pass
    if unbanned:
        e = discord.Embed(title="🔓 Разбан жертв", description="\n".join(unbanned[:20]), color=0x00ff00)
        await send_log(guild, e)


# ========================= СОБЫТИЯ ===========================
@bot.event
async def on_ready():
    print(f"✅ {bot.user} | Префикс: .")
    for guild in bot.guilds:
        invites = await get_invites(guild)
        invite_cache[guild.id] = {code: inv.uses for code, inv in invites.items()}
    await bot.change_presence(activity=discord.Activity(
        type=discord.ActivityType.watching, name="АНТИНЮК | .help"
    ))
    bot.loop.create_task(auto_backup_task())
    bot.loop.create_task(cleanup_old_backups())
    bot.loop.create_task(auto_save_settings_task())
    bot.loop.create_task(cleanup_punished())
    bot.loop.create_task(cleanup_nuke_tracker())


@bot.event
async def on_invite_create(invite):
    guild = invite.guild
    if guild.id not in invite_cache:
        invite_cache[guild.id] = {}
    invite_cache[guild.id][invite.code] = invite.uses


@bot.event
async def on_invite_delete(invite):
    guild = invite.guild
    if guild.id in invite_cache:
        invite_cache[guild.id].pop(invite.code, None)


@bot.event
async def on_voice_state_update(member, before, after):
    now = datetime.now(timezone.utc)
    key = f"{member.guild.id}_{member.id}"
    if before.channel is None and after.channel is not None:
        voice_tracker[key] = {"total": 0, "join_time": now, "name": str(member), "guild_id": member.guild.id}
    elif before.channel is not None and after.channel is None:
        if key in voice_tracker and "join_time" in voice_tracker[key]:
            voice_tracker[key]["total"] += (now - voice_tracker[key]["join_time"]).total_seconds()
            voice_tracker[key].pop("join_time", None)
    elif before.channel is not None and after.channel is not None and before.channel != after.channel:
        if key in voice_tracker and "join_time" in voice_tracker[key]:
            voice_tracker[key]["total"] += (now - voice_tracker[key]["join_time"]).total_seconds()
            voice_tracker[key]["join_time"] = now


@bot.event
async def on_member_update(before, after):
    if before.roles == after.roles: return
    guild = after.guild
    now = datetime.now(timezone.utc)
    added_roles = [r for r in after.roles if r not in before.roles]
    for role in added_roles:
        if not role.permissions.administrator: continue
        await asyncio.sleep(0.5)
        grantor = None
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.member_role_update):
                if (entry.target.id == after.id and role in entry.after.roles
                        and (now - entry.created_at).total_seconds() < 10):
                    grantor = entry.user
                    break
        except:
            continue
        if not grantor: continue
        if grantor.id == OWNER_ID or grantor == bot.user or grantor.id == guild.owner_id: continue
        if is_prota_user(grantor.id):
            e = discord.Embed(title="ℹ️ Прота выдал admin", color=0x5865F2, timestamp=now)
            e.add_field(name="Выдал", value=f"{grantor}")
            e.add_field(name="Получил", value=f"{after}")
            e.add_field(name="Роль", value=role.name)
            await send_log(guild, e)
            continue
        try:
            await after.remove_roles(role, reason="Антирейд: незаконная админка")
            try:
                await after.ban(reason="Антирейд: незаконная админка")
            except:
                pass
            try:
                if isinstance(grantor, discord.Member):
                    await grantor.ban(reason="Антирейд: выдал админку")
                else:
                    await guild.ban(grantor, reason="Антирейд: выдал админку")
            except:
                pass
            if grantor.id in WHITELIST_USERS: WHITELIST_USERS.remove(grantor.id)
            if grantor.id in PROTA_USERS: PROTA_USERS.remove(grantor.id)
            if after.id in WHITELIST_USERS: WHITELIST_USERS.remove(after.id)
            if after.id in PROTA_USERS: PROTA_USERS.remove(after.id)
            save_settings()
            e = discord.Embed(title="🚨 АНТИ-ЗАХВАТ", color=0xff0000, timestamp=now)
            e.add_field(name="Выдал", value=f"{grantor}")
            e.add_field(name="Получил", value=f"{after}")
            e.add_field(name="Роль", value=role.name)
            await send_log(guild, e)
        except:
            pass
        break


@bot.event
async def on_member_join(member: discord.Member):
    guild = member.guild
    now = datetime.now(timezone.utc)

    # ========================= WELCOME =========================
    if WELCOME_ENABLED and WELCOME_CHANNEL_ID and not member.bot:
        welcome_ch = guild.get_channel(WELCOME_CHANNEL_ID)
        if welcome_ch:
            try:
                embed = discord.Embed(
                    title=format_welcome(WELCOME_TITLE, member),
                    description=format_welcome(WELCOME_TEXT, member),
                    color=WELCOME_COLOR,
                    timestamp=now
                )
                embed.set_thumbnail(url=member.display_avatar.url)
                if WELCOME_GIF_URL:
                    embed.set_image(url=WELCOME_GIF_URL)
                embed.set_footer(text=f"ID: {member.id} | Всего участников: {guild.member_count}")
                await welcome_ch.send(content=member.mention, embed=embed)
            except Exception as ex:
                print(f"[WELCOME] Ошибка: {ex}")

    if not member.bot:
        if AUTO_ROLE_ID:
            try:
                role = guild.get_role(AUTO_ROLE_ID)
                if role: await member.add_roles(role)
            except:
                pass
        if AUTO_NICK_ENABLED:
            try:
                await member.edit(nick=f"{AUTO_NICK_PREFIX}{member.display_name}"[:32])
            except:
                pass

    if member.bot:
        if is_verified_bot(member):
            await send_log(guild, discord.Embed(
                title="✅ Верифицированный бот",
                description=f"{member.mention} пропущен.",
                color=0x00ff00
            ))
            return
        if member.id in WHITELIST_BOTS:
            await send_log(guild, discord.Embed(
                title="✅ Бот в вайтлисте",
                description=f"{member.mention} пропущен.",
                color=0x00ff00
            ))
            return
        adder = None
        try:
            async for entry in guild.audit_logs(limit=5, action=discord.AuditLogAction.bot_add):
                if entry.target.id == member.id:
                    adder = entry.user
                    break
        except:
            pass
        if not adder:
            try:
                await member.ban(reason="Антирейд: неизвестный добавил бота")
            except:
                pass
            return
        if is_prota_user(adder.id):
            if member.id not in WHITELIST_BOTS:
                WHITELIST_BOTS.append(member.id)
                save_settings()
            await send_log(guild, discord.Embed(
                title="✅ Прота добавил бота",
                description=f"{member.mention} добавлен {adder}",
                color=0x00ff00
            ))
            return
        try:
            try:
                removable = [r for r in member.roles if not r.is_default() and not r.managed and r < guild.me.top_role]
                if removable:
                    await member.remove_roles(*removable, reason="АНТИНЮК")
            except:
                pass
            await asyncio.sleep(0.2)
            try:
                await member.ban(reason="Антирейд: незаконный бот")
            except:
                pass
            try:
                adder_m = guild.get_member(adder.id)
                if adder_m:
                    await adder_m.ban(reason="Антирейд: добавление бота")
                else:
                    await guild.ban(adder, reason="Антирейд: добавление бота")
            except:
                pass
            if adder.id in WHITELIST_USERS: WHITELIST_USERS.remove(adder.id)
            if adder.id in PROTA_USERS: PROTA_USERS.remove(adder.id)
            save_settings()
            e = discord.Embed(title="🚨 НЕЗАКОННЫЙ БОТ ЗАБАНЕН", color=0xff0000, timestamp=now)
            e.add_field(name="Бот", value=f"{member} (`{member.id}`)")
            e.add_field(name="Добавил", value=f"{adder} (`{adder.id}`)")
            await send_log(guild, e)
        except:
            pass
        return

    used_invite = None
    inviter = None
    invite_code = None
    try:
        current_invites = {}
        try:
            fetched = await guild.invites()
            current_invites = {inv.code: inv for inv in fetched}
        except:
            pass
        old_invites = invite_cache.get(guild.id, {})
        for code, inv in current_invites.items():
            if inv.uses > old_invites.get(code, 0):
                used_invite = inv
                inviter = inv.inviter
                invite_code = code
                break
        if not used_invite:
            for code in old_invites:
                if code not in current_invites:
                    invite_code = code
                    break
        invite_cache[guild.id] = {code: inv.uses for code, inv in current_invites.items()}
    except:
        pass

    created_at = member.created_at.replace(tzinfo=timezone.utc) if member.created_at.tzinfo is None else member.created_at
    account_age = (now - created_at).days
    e = discord.Embed(title="👋 Новый участник", color=0x00ff00, timestamp=now)
    e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="Участник", value=f"{member.mention} `{member.id}`")
    e.add_field(name="Аккаунт", value=f"<t:{int(created_at.timestamp())}:R> ({account_age} дн.)")
    if used_invite and inviter:
        e.add_field(name="Пригласил", value=inviter.mention)
        e.add_field(name="Инвайт", value=f"discord.gg/{used_invite.code}")
    elif invite_code:
        e.add_field(name="Инвайт", value=invite_code)
    if account_age < 7:
        e.add_field(name="⚠️ Новый акк", value=f"{account_age} дн.")
        e.color = 0xff6600
    await send_invite_log(guild, e)


@bot.event
async def on_member_remove(member: discord.Member):
    guild = member.guild
    now = datetime.now(timezone.utc)
    if member.bot: return
    action_text = "👋 Покинул"
    action_color = 0xff9900
    moderator = None
    reason = None
    try:
        async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.kick):
            if entry.target.id == member.id and (now - entry.created_at).total_seconds() < 5:
                action_text = "👢 Кикнут"
                action_color = 0xff6600
                moderator = entry.user
                reason = entry.reason
                await check_and_punish(guild, entry.user.id, "kick")
                break
        if not moderator:
            async for entry in guild.audit_logs(limit=3, action=discord.AuditLogAction.ban):
                if entry.target.id == member.id and (now - entry.created_at).total_seconds() < 5:
                    action_text = "🔨 Забанен"
                    action_color = 0xff0000
                    moderator = entry.user
                    reason = entry.reason
                    break
    except:
        pass
    joined = member.joined_at.replace(tzinfo=timezone.utc) if member.joined_at and member.joined_at.tzinfo is None else member.joined_at
    days = (now - joined).days if joined else 0
    e = discord.Embed(title=action_text, color=action_color, timestamp=now)
    if member.display_avatar:
        e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="Участник", value=f"{member} ({member.id})")
    e.add_field(name="Был", value=f"{days} дн.")
    if moderator:
        e.add_field(name="Модератор", value=moderator.mention)
    if reason:
        e.add_field(name="Причина", value=reason[:500])
    await send_invite_log(guild, e)


@bot.event
async def on_raw_reaction_add(payload):
    if payload.user_id == bot.user.id: return
    is_role = payload.message_id in role_requests
    is_gen = payload.message_id in general_requests
    if not is_role and not is_gen: return
    guild = bot.get_guild(payload.guild_id)
    if not guild: return
    moderator = guild.get_member(payload.user_id)
    if not moderator or not (
        moderator.guild_permissions.manage_roles
        or moderator.id == OWNER_ID
        or is_whitelist_user(moderator)
    ):
        return
    emoji = str(payload.emoji)
    if emoji not in ("✅", "❌"): return
    channel = guild.get_channel(payload.channel_id)
    try:
        msg = await channel.fetch_message(payload.message_id)
    except:
        role_requests.pop(payload.message_id, None)
        general_requests.pop(payload.message_id, None)
        return
    now = datetime.now(timezone.utc)
    if is_role:
        req = role_requests[payload.message_id]
        target = guild.get_member(req["user_id"])
        role = guild.get_role(req["role_id"])
        if not target or not role:
            del role_requests[payload.message_id]
            return
        if emoji == "✅":
            try:
                if req["action"] == "give":
                    await target.add_roles(role)
                else:
                    await target.remove_roles(role)
                result_e = discord.Embed(
                    title="✅ Роль выдана" if req["action"] == "give" else "✅ Роль снята",
                    color=0x00ff00, timestamp=now
                )
                result_e.add_field(name="Участник", value=target.mention)
                result_e.add_field(name="Роль", value=role.mention)
                result_e.add_field(name="Одобрил", value=moderator.mention)
                await msg.edit(embed=result_e)
                await msg.clear_reactions()
            except:
                pass
            del role_requests[payload.message_id]
        else:
            reject_e = discord.Embed(title="❌ Отклонено", color=0xff0000, timestamp=now)
            reject_e.add_field(name="Участник", value=target.mention)
            reject_e.add_field(name="Роль", value=role.mention)
            reject_e.add_field(name="Отклонил", value=moderator.mention)
            await msg.edit(embed=reject_e)
            await msg.clear_reactions()
            del role_requests[payload.message_id]
    elif is_gen:
        req = general_requests[payload.message_id]
        target = guild.get_member(req["user_id"])
        if not target:
            del general_requests[payload.message_id]
            return
        fields = req.get("fields", {})
        if emoji == "✅":
            emb = discord.Embed(title="✅ ОДОБРЕНА", color=0x00ff00, timestamp=now)
            emb.add_field(name="👤", value=target.mention, inline=False)
            for k, v in fields.items():
                if v: emb.add_field(name=k, value=v[:200], inline=False)
            emb.add_field(name="👮 Одобрил", value=moderator.mention)
        else:
            emb = discord.Embed(title="❌ ОТКЛОНЕНА", color=0xff0000, timestamp=now)
            emb.add_field(name="👤", value=target.mention, inline=False)
            emb.add_field(name="👮 Отклонил", value=moderator.mention)
        await msg.edit(embed=emb)
        await msg.clear_reactions()
        del general_requests[payload.message_id]


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot: return
    if not message.guild: return await bot.process_commands(message)
    if (GENERAL_REQUEST_CHANNEL_ID
            and message.channel.id == GENERAL_REQUEST_CHANNEL_ID
            and not message.content.startswith(".")):
        await create_general_request_from_message(message)
        return
    member = message.author
    now = datetime.now(timezone.utc)
    if RAID_MODE:
        if (message.channel.id not in ALLOWED_LINK_CHANNELS and LINK_PATTERN.search(message.content)):
            is_gif = any(
                a.filename.lower().endswith(".gif") for a in message.attachments
            ) or any(
                d in message.content.lower()
                for d in ["tenor.com", "giphy.com", "media.tenor.com", "media.giphy.com"]
            )
            if not is_gif:
                if any(d in message.content.lower() for d in ALLOWED_DOMAINS):
                    pass
                elif is_whitelist_user(member):
                    key = f"wl_link_{member.guild.id}_{member.id}"
                    whitelist_link_tracker[key] = [
                        t for t in whitelist_link_tracker[key]
                        if now - t < timedelta(seconds=WHITELIST_LINK_TIME)
                    ] + [now]
                    if len(whitelist_link_tracker[key]) > WHITELIST_LINK_LIMIT:
                        try:
                            await message.delete()
                            await member.timeout(timedelta(minutes=10), reason="Лимит ссылок")
                            whitelist_link_tracker[key].clear()
                        except:
                            pass
                        return
                elif not is_whitelisted(member):
                    try:
                        await message.delete()
                    except:
                        pass
                    return
        if not is_whitelisted(member):
            if contains_banned_phrase(message.content):
                try:
                    await message.delete()
                except:
                    pass
                return
            key = f"{message.guild.id}-{member.id}"
            message_tracker[key] = [
                t for t in message_tracker[key]
                if now - t < timedelta(seconds=5)
            ] + [now]
            if len(message_tracker[key]) >= 7:
                try:
                    await member.timeout(timedelta(minutes=30), reason="Антифлуд")
                    message_tracker[key].clear()
                except:
                    pass
    await bot.process_commands(message)


@bot.event
async def on_message_edit(before, after):
    if after.author.bot or not after.guild: return
    if not RAID_MODE or after.channel.id in ALLOWED_LINK_CHANNELS: return
    if not LINK_PATTERN.search(after.content): return
    for d in ["tenor.com", "giphy.com"]:
        if d in after.content.lower(): return
    if any(d in after.content.lower() for d in ALLOWED_DOMAINS): return
    if after.author.id in PROTA_USERS: return
    try:
        await after.delete()
        await after.author.timeout(timedelta(minutes=5), reason="Ссылка через редактирование")
    except:
        pass


async def create_general_request_from_message(message):
    member = message.author
    text = message.content
    image_url = None
    for att in message.attachments:
        if att.content_type and att.content_type.startswith("image/"):
            image_url = att.url
            break
    if not text and not image_url: return
    if GENERAL_APPROVE_CHANNEL_ID == 0: return
    approve_channel = message.guild.get_channel(GENERAL_APPROVE_CHANNEL_ID)
    if not approve_channel: return
    emb = discord.Embed(title="📨 ЗАЯВКА", color=0x5865F2, timestamp=datetime.now(timezone.utc))
    emb.set_thumbnail(url=member.display_avatar.url)
    emb.add_field(name="👤", value=f"{member.mention} ({member.id})", inline=False)
    if text: emb.add_field(name="📝", value=text[:1000], inline=False)
    if image_url: emb.set_image(url=image_url)
    emb.set_footer(text="✅ — Одобрить | ❌ — Отклонить")
    msg = await approve_channel.send(embed=emb)
    await msg.add_reaction("✅")
    await msg.add_reaction("❌")
    general_requests[msg.id] = {
        "user_id": member.id, "text": text, "image_url": image_url,
        "guild_id": message.guild.id, "channel_id": message.channel.id,
        "message_id": msg.id, "fields": {}
    }
    try:
        await message.delete()
    except:
        pass


# ========================= МОДАЛКА =========================
class RequestModal(ui.Modal, title="📨 Подать заявку"):
    age = ui.TextInput(label="Сколько лет", style=discord.TextStyle.short, required=True, max_length=3)
    clans = ui.TextInput(label="В каких кланах были", style=discord.TextStyle.paragraph, required=False, max_length=500)
    heal = ui.TextInput(label="Как правильно хилится", style=discord.TextStyle.paragraph, required=True, max_length=500)
    extra_text = ui.TextInput(label="Дополнительно", style=discord.TextStyle.paragraph, required=False, max_length=500)
    image_url = ui.TextInput(label="Ссылка на изображение", style=discord.TextStyle.short, required=False, max_length=300)

    async def on_submit(self, interaction: discord.Interaction):
        guild = interaction.guild
        member = interaction.user
        if not GENERAL_APPROVE_CHANNEL_ID:
            return await interaction.response.send_message("❌ Не настроено.", ephemeral=True)
        ch = guild.get_channel(GENERAL_APPROVE_CHANNEL_ID)
        if not ch:
            return await interaction.response.send_message("❌ Канал не найден.", ephemeral=True)
        emb = discord.Embed(title="📨 ЗАЯВКА", color=0x5865F2, timestamp=datetime.now(timezone.utc))
        emb.set_thumbnail(url=member.display_avatar.url)
        emb.add_field(name="👤", value=f"{member.mention} (`{member.id}`)", inline=False)
        emb.add_field(name="🎂 Возраст", value=self.age.value.strip())
        if self.clans.value.strip():
            emb.add_field(name="🏰 Кланы", value=self.clans.value.strip(), inline=False)
        emb.add_field(name="💊 Хил", value=self.heal.value.strip(), inline=False)
        if self.extra_text.value.strip():
            emb.add_field(name="📝", value=self.extra_text.value.strip(), inline=False)
        img = self.image_url.value.strip()
        if img: emb.set_image(url=img)
        emb.set_footer(text="✅ — Одобрить | ❌ — Отклонить")
        msg = await ch.send(embed=emb)
        await msg.add_reaction("✅")
        await msg.add_reaction("❌")
        general_requests[msg.id] = {
            "user_id": member.id, "image_url": img or None,
            "guild_id": guild.id, "channel_id": interaction.channel_id,
            "message_id": msg.id,
            "fields": {
                "age": self.age.value.strip(), "clans": self.clans.value.strip(),
                "heal": self.heal.value.strip(), "extra": self.extra_text.value.strip()
            }
        }
        await interaction.response.send_message("✅ Заявка отправлена!", ephemeral=True)


class RequestView(ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @ui.button(label="📩 Подать заявку", style=discord.ButtonStyle.primary, custom_id="request_button")
    async def request_button(self, interaction: discord.Interaction, button: ui.Button):
        await interaction.response.send_modal(RequestModal())


# ========================= КОМАНДЫ BACKUP =========================
@bot.group(invoke_without_command=True)
async def backup(ctx):
    if ctx.invoked_subcommand is None:
        if not await protection_check(ctx): return
        msg = await ctx.send("⏳ Создаю бэкап...")
        data = await create_backup(ctx.guild, "manual")
        e = discord.Embed(title="💾 Бэкап создан", color=0x00ff00)
        e.add_field(name="Ролей", value=len(data["roles"]))
        e.add_field(name="Текст. каналов", value=len(data["text_channels"]))
        e.add_field(name="Голос. каналов", value=len(data["voice_channels"]))
        e.add_field(name="Категорий", value=len(data["categories"]))
        await msg.edit(content=None, embed=e)


@backup.command(name="list")
async def backup_list(ctx):
    if not await protection_check(ctx): return
    if not os.path.exists(BACKUP_FOLDER):
        return await ctx.send("❌ Нет бэкапов.")
    files = sorted(
        [f for f in os.listdir(BACKUP_FOLDER) if f.endswith(".json") and str(ctx.guild.id) in f],
        key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER, x)), reverse=True
    )
    if not files: return await ctx.send("📂 Пусто.")
    lines = []
    for i, f in enumerate(files[:20], 1):
        try:
            with open(os.path.join(BACKUP_FOLDER, f), "r", encoding="utf-8") as fp:
                bd = json.load(fp)
            created = bd.get("created_at", "—")[:19]
            reason = bd.get("reason", "—")
        except:
            created = "—"
            reason = "—"
        lines.append(f"**{i}.** `{f}`\n    📅 {created} | 📌 {reason}")
    e = discord.Embed(title="📂 Бэкапы", description="\n".join(lines), color=0x5865F2)
    e.set_footer(text=f"Всего: {len(files)}")
    await ctx.send(embed=e)


@backup.command(name="load")
async def backup_load(ctx, number: int = None):
    if not await protection_check(ctx): return
    if not number: return await ctx.send("❌ `.backup load <номер>`")
    if not os.path.exists(BACKUP_FOLDER): return await ctx.send("❌ Нет бэкапов.")
    files = sorted(
        [f for f in os.listdir(BACKUP_FOLDER) if f.endswith(".json") and str(ctx.guild.id) in f],
        key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER, x)), reverse=True
    )
    if number < 1 or number > len(files):
        return await ctx.send(f"❌ Доступно: 1–{len(files)}")
    filename = files[number - 1]
    try:
        with open(os.path.join(BACKUP_FOLDER, filename), "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as ex:
        return await ctx.send(f"❌ Ошибка чтения: {ex}")
    e = discord.Embed(title="⚠️ ПОЛНОЕ ВОССТАНОВЛЕНИЕ СЕРВЕРА", color=0xff0000)
    e.description = (
        f"**Файл:** `{filename}`\n"
        f"**Дата:** {data.get('created_at', '—')[:19]}\n"
        f"**Причина бэкапа:** {data.get('reason', '—')}\n\n"
        f"📊 **В бэкапе:**\n"
        f"• Ролей: **{len(data.get('roles', []))}**\n"
        f"• Категорий: **{len(data.get('categories', []))}**\n"
        f"• Текстовых каналов: **{len(data.get('text_channels', []))}**\n"
        f"• Голосовых каналов: **{len(data.get('voice_channels', []))}**\n\n"
        f"⚠️ **Это действие удалит каналы которых нет в бэкапе!**\n\n"
        f"✅ — Начать | ❌ — Отмена"
    )
    msg = await ctx.send(embed=e)
    await msg.add_reaction("✅")
    await msg.add_reaction("❌")

    def check(r, u):
        return u == ctx.author and r.message.id == msg.id and str(r.emoji) in ("✅", "❌")

    try:
        reaction, _ = await bot.wait_for("reaction_add", timeout=30, check=check)
    except asyncio.TimeoutError:
        await msg.delete()
        return await ctx.send("❌ Время вышло.", delete_after=5)
    if str(reaction.emoji) == "❌":
        await msg.delete()
        return await ctx.send("✅ Отменено.", delete_after=5)
    await msg.delete()
    status_msg = await ctx.send("🔄 **Начинаю восстановление...**")
    try:
        result = await full_restore_backup(ctx.guild, data, status_msg)
    except Exception as ex:
        return await status_msg.edit(content=f"❌ Критическая ошибка: {ex}")
    now = datetime.now(timezone.utc)
    report = discord.Embed(title="✅ ВОССТАНОВЛЕНИЕ ЗАВЕРШЕНО", color=0x00ff00, timestamp=now)
    report.add_field(name="🎭 Роли", value=f"Создано: **{len(result['roles_created'])}**\nОбновлено: **{len(result['roles_updated'])}**\nОшибок: **{len(result['roles_errors'])}**", inline=True)
    report.add_field(name="📁 Категории", value=f"Создано: **{len(result['categories_created'])}**\nОбновлено: **{len(result['categories_updated'])}**\nОшибок: **{len(result['cat_errors'])}**", inline=True)
    report.add_field(name="💬 Текст. каналы", value=f"Создано: **{len(result['text_created'])}**\nОбновлено: **{len(result['text_updated'])}**\nОшибок: **{len(result['text_errors'])}**", inline=True)
    report.add_field(name="🔊 Голос. каналы", value=f"Создано: **{len(result['voice_created'])}**\nОбновлено: **{len(result['voice_updated'])}**\nОшибок: **{len(result['voice_errors'])}**", inline=True)
    report.add_field(name="🗑️ Удалено каналов", value=f"**{len(result['channels_deleted'])}**", inline=True)
    all_errors = result['roles_errors'] + result['cat_errors'] + result['text_errors'] + result['voice_errors']
    if all_errors:
        report.add_field(name="⚠️ Ошибки", value="\n".join(all_errors[:8]), inline=False)
    report.set_footer(text=f"Бэкап: {filename}")
    await status_msg.edit(content=None, embed=report)
    await send_log(ctx.guild, discord.Embed(
        title="💾 Восстановление из бэкапа",
        description=f"**Инициатор:** {ctx.author.mention}\n**Файл:** `{filename}`",
        color=0x5865F2, timestamp=now
    ))


@backup.command(name="quickrestore")
async def backup_quickrestore(ctx):
    if not await protection_check(ctx): return
    if not os.path.exists(BACKUP_FOLDER): return await ctx.send("❌ Нет бэкапов.")
    files = sorted(
        [f for f in os.listdir(BACKUP_FOLDER) if f.endswith(".json") and str(ctx.guild.id) in f],
        key=lambda x: os.path.getmtime(os.path.join(BACKUP_FOLDER, x)), reverse=True
    )
    if not files: return await ctx.send("❌ Нет бэкапов.")
    filename = files[0]
    try:
        with open(os.path.join(BACKUP_FOLDER, filename), "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as ex:
        return await ctx.send(f"❌ Ошибка: {ex}")
    status_msg = await ctx.send(f"⚡ **Быстрое восстановление из** `{filename}`...")
    guild = ctx.guild
    result = {"created": 0, "updated": 0, "errors": 0}
    role_id_map = {}
    for rd in data.get("roles", []):
        try:
            ex = discord.utils.get(guild.roles, name=rd["name"])
            if ex:
                role_id_map[rd["id"]] = ex
            else:
                nr = await guild.create_role(
                    name=rd["name"], color=discord.Color(rd.get("color", 0)),
                    hoist=rd.get("hoist", False), mentionable=rd.get("mentionable", False),
                    permissions=discord.Permissions(rd.get("permissions", 0)),
                    reason="Быстрое восстановление"
                )
                role_id_map[rd["id"]] = nr
                result["created"] += 1
                await asyncio.sleep(0.3)
        except:
            result["errors"] += 1
    cat_id_map = {}
    for cd in data.get("categories", []):
        try:
            overwrites = build_overwrites(guild, cd.get("overwrites", []), role_id_map)
            ex = discord.utils.get(guild.categories, name=cd["name"])
            if ex:
                cat_id_map[cd["id"]] = ex
                result["updated"] += 1
            else:
                nc = await guild.create_category(name=cd["name"], overwrites=overwrites, reason="Быстрое восстановление")
                cat_id_map[cd["id"]] = nc
                result["created"] += 1
                await asyncio.sleep(0.3)
        except:
            result["errors"] += 1
    for ch in data.get("text_channels", []):
        try:
            overwrites = build_overwrites(guild, ch.get("overwrites", []), role_id_map)
            cat = cat_id_map.get(ch.get("category_id")) or discord.utils.get(guild.categories, name=ch.get("category_name"))
            ex = discord.utils.get(guild.text_channels, name=ch["name"])
            if ex:
                await ex.edit(topic=ch.get("topic"), slowmode_delay=ch.get("slowmode", 0), nsfw=ch.get("nsfw", False), category=cat, overwrites=overwrites, reason="Быстрое восстановление")
                result["updated"] += 1
            else:
                await guild.create_text_channel(name=ch["name"], topic=ch.get("topic"), slowmode_delay=ch.get("slowmode", 0), nsfw=ch.get("nsfw", False), category=cat, overwrites=overwrites, reason="Быстрое восстановление")
                result["created"] += 1
                await asyncio.sleep(0.3)
        except:
            result["errors"] += 1
    for ch in data.get("voice_channels", []):
        try:
            overwrites = build_overwrites(guild, ch.get("overwrites", []), role_id_map)
            cat = cat_id_map.get(ch.get("category_id")) or discord.utils.get(guild.categories, name=ch.get("category_name"))
            ex = discord.utils.get(guild.voice_channels, name=ch["name"])
            if ex:
                await ex.edit(bitrate=min(ch.get("bitrate", 64000), guild.bitrate_limit), user_limit=ch.get("user_limit", 0), category=cat, overwrites=overwrites, reason="Быстрое восстановление")
                result["updated"] += 1
            else:
                await guild.create_voice_channel(name=ch["name"], bitrate=min(ch.get("bitrate", 64000), guild.bitrate_limit), user_limit=ch.get("user_limit", 0), category=cat, overwrites=overwrites, reason="Быстрое восстановление")
                result["created"] += 1
                await asyncio.sleep(0.3)
        except:
            result["errors"] += 1
    await restore_channel_positions(guild, data, cat_id_map)
    e = discord.Embed(title="⚡ Быстрое восстановление завершено", color=0x00ff00)
    e.add_field(name="Создано", value=result["created"])
    e.add_field(name="Обновлено", value=result["updated"])
    e.add_field(name="Ошибок", value=result["errors"])
    e.set_footer(text=f"Бэкап: {filename}")
    await status_msg.edit(content=None, embed=e)


# ========================= WELCOME КОМАНДЫ =========================
@bot.command(name="setwelcomechannel")
async def setwelcomechannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global WELCOME_CHANNEL_ID
    channel = channel or ctx.channel
    WELCOME_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(embed=discord.Embed(title="✅ Канал приветствий", description=f"{channel.mention}", color=0x00ff00))


@bot.command(name="setwelcometext")
async def setwelcometext(ctx, *, text: str = None):
    if not await protection_check(ctx): return
    if not text:
        return await ctx.send(
            "❌ Укажи текст.\n\n**Переменные:**\n"
            "`{user}` — упоминание\n`{user.name}` — имя\n"
            "`{user.id}` — ID\n`{server}` — сервер\n"
            "`{membercount}` — кол-во участников\n`{nl}` — новая строка"
        )
    global WELCOME_TEXT
    WELCOME_TEXT = text
    save_settings()
    preview = format_welcome(text, ctx.author)
    e = discord.Embed(title="✅ Текст приветствия обновлён", color=0x00ff00)
    e.add_field(name="📝 Исходный", value=f"```{text[:400]}```", inline=False)
    e.add_field(name="👁️ Превью", value=preview[:900], inline=False)
    await ctx.send(embed=e)


@bot.command(name="setwelcometitle")
async def setwelcometitle(ctx, *, title: str = None):
    if not await protection_check(ctx): return
    global WELCOME_TITLE
    if not title:
        WELCOME_TITLE = ""
        save_settings()
        return await ctx.send("✅ Заголовок убран.")
    WELCOME_TITLE = title
    save_settings()
    await ctx.send(embed=discord.Embed(title="✅ Заголовок обновлён", description=f"**{title}**", color=0x00ff00))


@bot.command(name="setwelcomegif")
async def setwelcomegif(ctx, url: str = None):
    if not await protection_check(ctx): return
    global WELCOME_GIF_URL
    if ctx.message.attachments:
        WELCOME_GIF_URL = ctx.message.attachments[0].url
        save_settings()
        e = discord.Embed(title="✅ GIF/картинка установлена", color=0x00ff00)
        e.set_image(url=WELCOME_GIF_URL)
        return await ctx.send(embed=e)
    if url:
        WELCOME_GIF_URL = url
        save_settings()
        e = discord.Embed(title="✅ GIF/картинка установлена", color=0x00ff00)
        e.set_image(url=WELCOME_GIF_URL)
        return await ctx.send(embed=e)
    WELCOME_GIF_URL = ""
    save_settings()
    await ctx.send(embed=discord.Embed(title="✅ GIF убрана", color=0x00ff00))


@bot.command(name="setwelcomecolor")
async def setwelcomecolor(ctx, color_hex: str = None):
    if not await protection_check(ctx): return
    if not color_hex: return await ctx.send("❌ `.setwelcomecolor #HEX`")
    global WELCOME_COLOR
    color_hex = color_hex.lstrip("#")
    try:
        color_int = int(color_hex, 16)
        if color_int > 0xFFFFFF: return await ctx.send("❌ Некорректный цвет.")
        WELCOME_COLOR = color_int
        save_settings()
        await ctx.send(embed=discord.Embed(title="✅ Цвет обновлён", description=f"`#{color_hex.upper()}`", color=color_int))
    except ValueError:
        await ctx.send("❌ Некорректный HEX. Пример: `#FF5733`")


@bot.command(name="welcomeon")
async def welcomeon(ctx):
    if not await protection_check(ctx): return
    global WELCOME_ENABLED
    WELCOME_ENABLED = True
    save_settings()
    ch_status = f"<#{WELCOME_CHANNEL_ID}>" if WELCOME_CHANNEL_ID else "⚠️ Канал не настроен!"
    await ctx.send(embed=discord.Embed(title="✅ Приветствия включены", description=f"Канал: {ch_status}", color=0x00ff00))


@bot.command(name="welcomeoff")
async def welcomeoff(ctx):
    if not await protection_check(ctx): return
    global WELCOME_ENABLED
    WELCOME_ENABLED = False
    save_settings()
    await ctx.send(embed=discord.Embed(title="❌ Приветствия выключены", color=0xff0000))


@bot.command(name="welcometest")
async def welcometest(ctx):
    if not await protection_check(ctx): return
    member = ctx.author
    try:
        embed = discord.Embed(
            title=format_welcome(WELCOME_TITLE, member),
            description=format_welcome(WELCOME_TEXT, member),
            color=WELCOME_COLOR,
            timestamp=datetime.now(timezone.utc)
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        if WELCOME_GIF_URL:
            embed.set_image(url=WELCOME_GIF_URL)
        embed.set_footer(text=f"ID: {member.id} | Всего участников: {ctx.guild.member_count}")
        await ctx.send(content=f"📌 **Тест приветствия**\n{member.mention}", embed=embed)
    except Exception as ex:
        await ctx.send(f"❌ Ошибка: {ex}")


@bot.command(name="welcomesettings")
async def welcomesettings(ctx):
    if not await protection_check(ctx): return
    channel = ctx.guild.get_channel(WELCOME_CHANNEL_ID) if WELCOME_CHANNEL_ID else None
    e = discord.Embed(title="👋 Настройки приветствий", color=WELCOME_COLOR)
    e.add_field(name="Статус", value="✅ Вкл" if WELCOME_ENABLED else "❌ Выкл", inline=True)
    e.add_field(name="Канал", value=channel.mention if channel else "❌ Не установлен", inline=True)
    e.add_field(name="Цвет", value=f"`#{WELCOME_COLOR:06X}`", inline=True)
    e.add_field(name="Заголовок", value=f"```{WELCOME_TITLE[:100]}```" if WELCOME_TITLE else "*(нет)*", inline=False)
    e.add_field(name="Текст", value=f"```{WELCOME_TEXT[:300]}```" if WELCOME_TEXT else "*(нет)*", inline=False)
    e.add_field(name="GIF", value=f"[Ссылка]({WELCOME_GIF_URL})" if WELCOME_GIF_URL else "❌ Нет", inline=True)
    if WELCOME_GIF_URL:
        e.set_image(url=WELCOME_GIF_URL)
    e.set_footer(text="Используй .welcometest для теста")
    await ctx.send(embed=e)


# ========================= ОСТАЛЬНЫЕ КОМАНДЫ =========================
@bot.command(name="say")
async def say_cmd(ctx, *, text: str = None):
    if not await protection_check(ctx): return
    if not text and not ctx.message.attachments: return await ctx.send("❌ Напиши текст.")
    files = [await a.to_file() for a in ctx.message.attachments]
    try: await ctx.message.delete()
    except: pass
    await ctx.send(content=text, files=files)


@bot.command(name="send")
async def send_cmd(ctx, channel: discord.TextChannel = None, *, text: str = None):
    if not await protection_check(ctx): return
    if not channel: return await ctx.send("❌ .send #канал текст")
    if not text and not ctx.message.attachments: return await ctx.send("❌ Напиши текст.")
    files = [await a.to_file() for a in ctx.message.attachments]
    try:
        await channel.send(content=text, files=files)
        await ctx.message.add_reaction("✅")
    except:
        await ctx.send("❌ Ошибка.")


@bot.command(name="sendembed")
async def sendembed_cmd(ctx, channel: discord.TextChannel = None, *, text: str = None):
    if not await protection_check(ctx): return
    if not channel or not text: return await ctx.send("❌ .sendembed #канал текст")
    embed = discord.Embed(description=text, color=0x5865F2)
    if ctx.message.attachments:
        embed.set_image(url=ctx.message.attachments[0].url)
    try:
        await channel.send(embed=embed)
        await ctx.message.add_reaction("✅")
    except:
        await ctx.send("❌ Ошибка.")


@bot.command(name="savesettings")
async def savesettings_cmd(ctx):
    if not await protection_check(ctx): return
    save_settings()
    await ctx.send(embed=discord.Embed(title="💾 Сохранено", color=0x00ff00))


@bot.command(name="antinukestatus")
async def antinukestatus(ctx):
    if not await protection_check(ctx): return
    e = discord.Embed(title="🛡️ АНТИНЮК", color=0x5865F2)
    e.add_field(name="⏱️ Окно", value=f"{ANTINUKE_WINDOW}с", inline=False)
    e.add_field(name="🤖 Лимиты ботов", value=f"Каналы удал: **{BOT_CHANNEL_DELETE_LIMIT}**\nКаналы созд: **{BOT_CHANNEL_CREATE_LIMIT}**\nРоли удал: **{BOT_ROLE_DELETE_LIMIT}**\nБаны: **{BOT_BAN_LIMIT}**\nВебхуки: **{BOT_WEBHOOK_LIMIT}**", inline=True)
    e.add_field(name="👤 Лимиты людей", value=f"Каналы удал: **{USER_CHANNEL_DELETE_LIMIT}**\nКаналы созд: **{USER_CHANNEL_CREATE_LIMIT}**\nРоли удал: **{USER_ROLE_DELETE_LIMIT}**\nБаны: **{USER_BAN_LIMIT}**\nВебхуки: **{USER_WEBHOOK_LIMIT}**", inline=True)
    e.add_field(name="📊 Наказано", value=str(len(punished_nukers)), inline=False)
    e.set_footer(text="Боты: ПЕРМ-БАН | Люди: Таймаут 28 дн")
    await ctx.send(embed=e)


@bot.command(name="help")
async def help_command(ctx):
    e = discord.Embed(title="🛡️ Антирейд бот", color=0x5865F2)
    e.add_field(name="⚔️ Антирейд", value=".raidon .raidoff .raidstatus .antinukestatus", inline=False)
    e.add_field(name="💾 Бэкапы", value=".backup — создать\n.backup list — список\n.backup load <№> — полное восстановление\n.backup quickrestore — быстрое восстановление\n.autobackup — авто вкл/выкл\n.lastbackup — последний бэкап", inline=False)
    e.add_field(name="👋 Приветствия", value=".welcomeon .welcomeoff .welcometest .welcomesettings\n.setwelcomechannel # .setwelcometext .setwelcometitle\n.setwelcomegif .setwelcomecolor", inline=False)
    e.add_field(name="✅ Вайтлист", value=".whitelistadd @ .whitelistremove @ .whitelistshow .clearwhitelist", inline=False)
    e.add_field(name="⭐ Прота", value=".protaadd @ .protaremove @ .protalist .clearprota", inline=False)
    e.add_field(name="🤖 Боты", value=".botwhitelistadd ID .botwhitelistremove ID .botwhitelistshow", inline=False)
    e.add_field(name="🔗 Ссылки", value=".linkson .linksoff .allowlink # .denylink #", inline=False)
    e.add_field(name="🌐 Домены", value=".adddomain .removedomain .listdomains", inline=False)
    e.add_field(name="🚫 Фразы", value=".addphrase .delphrase .listphrases", inline=False)
    e.add_field(name="📋 Заявки", value=".requestrole @роль .setapprovechannel # .sendrequestbutton #", inline=False)
    e.add_field(name="🔨 Мод", value=".ban @ .kick @ .mute @ [мин] .unmute @ .clear [N] .giverole .takerole .unbanall", inline=False)
    e.add_field(name="🎤 Голос", value=".voicetop .voiceinfo @ .voicenow", inline=False)
    e.add_field(name="💬 Сообщения", value=".say .send #канал .sendembed #канал", inline=False)
    e.add_field(name="📊 Логи", value=".setlogchannel # .setinvitelogchannel #", inline=False)
    e.add_field(name="🎭 Авто", value=".setautorole @роль .autonickon .autonickoff .setnickprefix .autosettings", inline=False)
    e.add_field(name="💾 Настройки", value=".savesettings .listall", inline=False)
    await ctx.send(embed=e)


@bot.command(name="myid")
async def my_id(ctx):
    await ctx.send(f"🪪 `{ctx.author.id}`")


@bot.command(name="ping")
async def ping(ctx):
    await ctx.send(f"🏓 {round(bot.latency * 1000)}мс")


@bot.command(name="serverinfo")
async def serverinfo(ctx):
    g = ctx.guild
    e = discord.Embed(title=f"📊 {g.name}", color=0x5865F2)
    if g.icon: e.set_thumbnail(url=g.icon.url)
    e.add_field(name="Участников", value=g.member_count)
    e.add_field(name="Ролей", value=len(g.roles))
    e.add_field(name="Каналов", value=len(g.channels))
    e.add_field(name="Создан", value=f"<t:{int(g.created_at.timestamp())}:R>")
    e.add_field(name="Владелец", value=g.owner.mention if g.owner else "—")
    await ctx.send(embed=e)


@bot.command(name="userinfo")
async def userinfo(ctx, member: discord.Member = None):
    member = member or ctx.author
    roles = [r.mention for r in member.roles if not r.is_default()]
    e = discord.Embed(title=f"👤 {member}", color=member.color)
    e.set_thumbnail(url=member.display_avatar.url)
    e.add_field(name="ID", value=member.id)
    e.add_field(name="Присоединился", value=f"<t:{int(member.joined_at.timestamp())}:R>" if member.joined_at else "—")
    e.add_field(name=f"Ролей ({len(roles)})", value=" ".join(roles[-10:]) if roles else "Нет", inline=False)
    await ctx.send(embed=e)


@bot.command(name="raidon")
async def raidon(ctx):
    if not await protection_check(ctx): return
    global RAID_MODE
    RAID_MODE = True
    save_settings()
    await ctx.send(embed=discord.Embed(title="🛡️ Антирейд ✅", color=0x00ff00))


@bot.command(name="raidoff")
async def raidoff(ctx):
    if not await protection_check(ctx): return
    global RAID_MODE
    RAID_MODE = False
    save_settings()
    await ctx.send(embed=discord.Embed(title="🛡️ Антирейд ❌", color=0xff0000))


@bot.command(name="raidstatus")
async def raidstatus(ctx):
    await ctx.send(embed=discord.Embed(
        title="🛡️ Антирейд",
        description="✅ ВКЛ" if RAID_MODE else "❌ ВЫКЛ",
        color=0x00ff00 if RAID_MODE else 0xff0000
    ))


@bot.command(name="autobackup")
async def autobackup_toggle(ctx):
    if not await protection_check(ctx): return
    global auto_backup_enabled
    auto_backup_enabled = not auto_backup_enabled
    save_settings()
    await ctx.send(embed=discord.Embed(title="🔄 Автобэкап", description="✅" if auto_backup_enabled else "❌", color=0x5865F2))


@bot.command(name="lastbackup")
async def lastbackup(ctx):
    if not await protection_check(ctx): return
    data = last_backup_data.get(ctx.guild.id)
    if not data: return await ctx.send("❌ Нет.")
    e = discord.Embed(title="💾 Последний бэкап", color=0x5865F2)
    e.add_field(name="Создан", value=data.get("created_at", "—")[:19])
    e.add_field(name="Причина", value=data.get("reason", "—"))
    e.add_field(name="Ролей", value=len(data.get("roles", [])))
    e.add_field(name="Каналов", value=len(data.get("text_channels", [])) + len(data.get("voice_channels", [])))
    await ctx.send(embed=e)


@bot.command(name="whitelistadd")
async def whitelistadd(ctx, member: discord.Member = None):
    if not await protection_check(ctx): return
    if not member: return await ctx.send("❌ .whitelistadd @")
    if member.id not in WHITELIST_USERS: WHITELIST_USERS.append(member.id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="✅ WL добавлен", description=member.mention, color=0x00ff00))


@bot.command(name="whitelistremove")
async def whitelistremove(ctx, member: discord.Member = None):
    if not await protection_check(ctx): return
    if not member: return await ctx.send("❌ .whitelistremove @")
    if member.id in WHITELIST_USERS: WHITELIST_USERS.remove(member.id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="✅ WL удалён", description=member.mention, color=0xff0000))


@bot.command(name="whitelistshow")
async def whitelistshow(ctx):
    if not await protection_check(ctx): return
    if not WHITELIST_USERS: return await ctx.send("Пусто.")
    lines = [ctx.guild.get_member(uid).mention if ctx.guild.get_member(uid) else str(uid) for uid in WHITELIST_USERS]
    await ctx.send(embed=discord.Embed(title="✅ Вайтлист", description="\n".join(lines), color=0x5865F2))


@bot.command(name="clearwhitelist")
async def clearwhitelist(ctx):
    if not await protection_check(ctx): return
    WHITELIST_USERS.clear()
    save_settings()
    await ctx.send("✅ Очищен.")


@bot.command(name="protaadd")
async def protaadd(ctx, member: discord.Member = None):
    if not await owner_check(ctx): return
    if not member: return await ctx.send("❌ .protaadd @")
    if member.id not in PROTA_USERS: PROTA_USERS.append(member.id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="⭐ Прота добавлен", description=member.mention, color=0x00ff00))


@bot.command(name="protaremove")
async def protaremove(ctx, member: discord.Member = None):
    if not await owner_check(ctx): return
    if not member: return await ctx.send("❌ .protaremove @")
    if member.id in PROTA_USERS: PROTA_USERS.remove(member.id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="⭐ Прота удалён", description=member.mention, color=0xff0000))


@bot.command(name="protalist")
async def protalist(ctx):
    if not await protection_check(ctx): return
    if not PROTA_USERS: return await ctx.send("Пусто.")
    lines = [ctx.guild.get_member(uid).mention if ctx.guild.get_member(uid) else str(uid) for uid in PROTA_USERS]
    await ctx.send(embed=discord.Embed(title="⭐ Прота", description="\n".join(lines), color=0x5865F2))


@bot.command(name="clearprota")
async def clearprota(ctx):
    if not await owner_check(ctx): return
    PROTA_USERS.clear()
    save_settings()
    await ctx.send("✅ Очищена.")


@bot.command(name="botwhitelistadd")
async def botwhitelistadd(ctx, bot_id: int = None):
    if not await protection_check(ctx): return
    if not bot_id: return await ctx.send("❌ .botwhitelistadd <ID>")
    if bot_id not in WHITELIST_BOTS: WHITELIST_BOTS.append(bot_id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="🤖 Добавлен", description=str(bot_id), color=0x00ff00))


@bot.command(name="botwhitelistremove")
async def botwhitelistremove(ctx, bot_id: int = None):
    if not await protection_check(ctx): return
    if not bot_id: return await ctx.send("❌ .botwhitelistremove <ID>")
    if bot_id in WHITELIST_BOTS: WHITELIST_BOTS.remove(bot_id)
    save_settings()
    await ctx.send(embed=discord.Embed(title="🤖 Удалён", description=str(bot_id), color=0xff0000))


@bot.command(name="botwhitelistshow")
async def botwhitelistshow(ctx):
    if not await protection_check(ctx): return
    if not WHITELIST_BOTS: return await ctx.send("Пусто.")
    await ctx.send(embed=discord.Embed(title="🤖 Бот-вайтлист", description="\n".join(str(b) for b in WHITELIST_BOTS), color=0x5865F2))


@bot.command(name="linkson")
async def linkson(ctx):
    if not await protection_check(ctx): return
    ALLOWED_LINK_CHANNELS.clear()
    save_settings()
    await ctx.send("✅ Анти-ссылки вкл.")


@bot.command(name="linksoff")
async def linksoff(ctx):
    if not await protection_check(ctx): return
    for ch in ctx.guild.text_channels:
        if ch.id not in ALLOWED_LINK_CHANNELS: ALLOWED_LINK_CHANNELS.append(ch.id)
    save_settings()
    await ctx.send("❌ Анти-ссылки выкл.")


@bot.command(name="allowlink")
async def allowlink(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    channel = channel or ctx.channel
    if channel.id not in ALLOWED_LINK_CHANNELS: ALLOWED_LINK_CHANNELS.append(channel.id)
    save_settings()
    await ctx.send(f"✅ Ссылки разрешены: {channel.mention}")


@bot.command(name="denylink")
async def denylink(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    channel = channel or ctx.channel
    if channel.id in ALLOWED_LINK_CHANNELS: ALLOWED_LINK_CHANNELS.remove(channel.id)
    save_settings()
    await ctx.send(f"❌ Ссылки запрещены: {channel.mention}")


@bot.command(name="adddomain")
async def adddomain(ctx, domain: str = None):
    if not await protection_check(ctx): return
    if not domain: return await ctx.send("❌ .adddomain example.com")
    if domain not in ALLOWED_DOMAINS: ALLOWED_DOMAINS.append(domain)
    save_settings()
    await ctx.send(f"✅ {domain}")


@bot.command(name="removedomain")
async def removedomain(ctx, domain: str = None):
    if not await protection_check(ctx): return
    if not domain: return await ctx.send("❌ .removedomain example.com")
    if domain in ALLOWED_DOMAINS: ALLOWED_DOMAINS.remove(domain)
    save_settings()
    await ctx.send(f"❌ {domain}")


@bot.command(name="listdomains")
async def listdomains(ctx):
    if not await protection_check(ctx): return
    await ctx.send(embed=discord.Embed(title="🌐 Домены", description="\n".join(ALLOWED_DOMAINS) or "Пусто", color=0x5865F2))


@bot.command(name="addphrase")
async def addphrase(ctx, *, phrase: str = None):
    if not await protection_check(ctx): return
    if not phrase: return await ctx.send("❌ .addphrase <фраза>")
    if phrase.lower() not in [p.lower() for p in BANNED_PHRASES]: BANNED_PHRASES.append(phrase)
    save_settings()
    await ctx.send("✅ Добавлено")


@bot.command(name="delphrase")
async def delphrase(ctx, *, phrase: str = None):
    if not await protection_check(ctx): return
    if not phrase: return await ctx.send("❌ .delphrase <фраза>")
    BANNED_PHRASES[:] = [p for p in BANNED_PHRASES if p.lower() != phrase.lower()]
    save_settings()
    await ctx.send("❌ Удалено")


@bot.command(name="listphrases")
async def listphrases(ctx):
    if not await protection_check(ctx): return
    await ctx.send(embed=discord.Embed(title="🚫 Фразы", description="\n".join(BANNED_PHRASES) or "Пусто", color=0x5865F2))


@bot.command(name="requestrole")
async def requestrole(ctx, role: discord.Role = None):
    if not role: return await ctx.send("❌ .requestrole @роль")
    if not ROLE_APPROVE_CHANNEL_ID: return await ctx.send("❌ Не настроено.")
    ch = ctx.guild.get_channel(ROLE_APPROVE_CHANNEL_ID)
    if not ch: return await ctx.send("❌ Канал не найден.")
    e = discord.Embed(title="📋 Заявка на роль", color=0x5865F2, timestamp=datetime.now(timezone.utc))
    e.add_field(name="Участник", value=ctx.author.mention)
    e.add_field(name="Роль", value=role.mention)
    e.set_footer(text="✅ — Выдать | ❌ — Отклонить")
    msg = await ch.send(embed=e)
    await msg.add_reaction("✅")
    await msg.add_reaction("❌")
    role_requests[msg.id] = {"user_id": ctx.author.id, "role_id": role.id, "action": "give", "channel_id": ctx.channel.id}
    await ctx.send("✅ Заявка отправлена", delete_after=5)


@bot.command(name="setapprovechannel")
async def setapprovechannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global ROLE_APPROVE_CHANNEL_ID
    channel = channel or ctx.channel
    ROLE_APPROVE_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(f"✅ Одобрение: {channel.mention}")


@bot.command(name="setgenrequestchannel")
async def setgenrequestchannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global GENERAL_REQUEST_CHANNEL_ID
    channel = channel or ctx.channel
    GENERAL_REQUEST_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(f"✅ Заявки: {channel.mention}")


@bot.command(name="setgenapprovechannel")
async def setgenapprovechannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global GENERAL_APPROVE_CHANNEL_ID
    channel = channel or ctx.channel
    GENERAL_APPROVE_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(f"✅ Одобрение заявок: {channel.mention}")


@bot.command(name="sendrequestbutton")
async def sendrequestbutton(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    channel = channel or ctx.channel
    await channel.send(
        embed=discord.Embed(title="📬 Подать заявку", description="Нажмите кнопку.", color=0x5865F2),
        view=RequestView()
    )
    await ctx.send("✅", delete_after=3)


@bot.command(name="setlogchannel")
async def setlogchannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global LOG_CHANNEL_ID
    channel = channel or ctx.channel
    LOG_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(f"✅ Логи: {channel.mention}")


@bot.command(name="setinvitelogchannel")
async def setinvitelogchannel(ctx, channel: discord.TextChannel = None):
    if not await protection_check(ctx): return
    global INVITE_LOG_CHANNEL_ID
    channel = channel or ctx.channel
    INVITE_LOG_CHANNEL_ID = channel.id
    save_settings()
    await ctx.send(f"✅ Инвайт-логи: {channel.mention}")


@bot.command(name="setautorole")
async def setautorole(ctx, role: discord.Role = None):
    if not await protection_check(ctx): return
    global AUTO_ROLE_ID
    AUTO_ROLE_ID = role.id if role else 0
    save_settings()
    await ctx.send(f"✅ Автороль: {role.mention if role else 'выкл'}")


@bot.command(name="autonickon")
async def autonickon(ctx):
    if not await protection_check(ctx): return
    global AUTO_NICK_ENABLED
    AUTO_NICK_ENABLED = True
    save_settings()
    await ctx.send(f"✅ Автоник вкл ({AUTO_NICK_PREFIX})")


@bot.command(name="autonickoff")
async def autonickoff(ctx):
    if not await protection_check(ctx): return
    global AUTO_NICK_ENABLED
    AUTO_NICK_ENABLED = False
    save_settings()
    await ctx.send("❌ Автоник выкл")


@bot.command(name="setnickprefix")
async def setnickprefix(ctx, *, prefix: str = None):
    if not await protection_check(ctx): return
    global AUTO_NICK_PREFIX
    if not prefix or len(prefix) > 10: return await ctx.send("❌ Укажи префикс (макс 10)")
    AUTO_NICK_PREFIX = prefix + " " if not prefix.endswith(" ") else prefix
    save_settings()
    await ctx.send(f"✅ Префикс: {AUTO_NICK_PREFIX}")


@bot.command(name="autosettings")
async def autosettings(ctx):
    if not await protection_check(ctx): return
    role = ctx.guild.get_role(AUTO_ROLE_ID) if AUTO_ROLE_ID else None
    e = discord.Embed(title="⚙️ Авто", color=0x5865F2)
    e.add_field(name="Автороль", value=role.mention if role else "выкл")
    e.add_field(name="Автоник", value=f"{'вкл' if AUTO_NICK_ENABLED else 'выкл'} | {AUTO_NICK_PREFIX}")
    await ctx.send(embed=e)


@bot.command(name="unbanall")
async def unbanall(ctx):
    if not await protection_check(ctx): return
    msg = await ctx.send("⚠️ Разбанить всех? ✅/❌")
    await msg.add_reaction("✅")
    await msg.add_reaction("❌")

    def check(r, u):
        return u == ctx.author and r.message.id == msg.id and str(r.emoji) in ("✅", "❌")

    try:
        r, _ = await bot.wait_for("reaction_add", timeout=30, check=check)
    except asyncio.TimeoutError:
        return await msg.delete()
    if str(r.emoji) == "❌": return await msg.delete()
    await msg.delete()
    w = await ctx.send("🔄 Разбан...")
    count = 0
    try:
        async for ban in ctx.guild.bans():
            try:
                await ctx.guild.unban(ban.user)
                count += 1
                await asyncio.sleep(0.5)
            except:
                pass
    except:
        pass
    await w.edit(content=f"✅ Разбанено: {count}")


@bot.command(name="ban")
@commands.has_permissions(ban_members=True)
async def ban_cmd(ctx, member: discord.Member = None, *, reason: str = "—"):
    if not member: return await ctx.send("❌ .ban @")
    try:
        await member.ban(reason=reason)
        await ctx.send(f"🔨 {member.mention} забанен")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="kick")
@commands.has_permissions(kick_members=True)
async def kick_cmd(ctx, member: discord.Member = None, *, reason: str = "—"):
    if not member: return await ctx.send("❌ .kick @")
    try:
        await member.kick(reason=reason)
        await ctx.send(f"👢 {member.mention} кикнут")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="mute")
@commands.has_permissions(moderate_members=True)
async def mute_cmd(ctx, member: discord.Member = None, minutes: int = 10):
    if not member: return await ctx.send("❌ .mute @ [мин]")
    try:
        await member.timeout(timedelta(minutes=minutes))
        await ctx.send(f"🔇 {member.mention} на {minutes}м")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="unmute")
@commands.has_permissions(moderate_members=True)
async def unmute_cmd(ctx, member: discord.Member = None):
    if not member: return await ctx.send("❌ .unmute @")
    try:
        await member.timeout(None)
        await ctx.send(f"🔊 {member.mention}")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="clear")
@commands.has_permissions(manage_messages=True)
async def clear_cmd(ctx, amount: int = 10):
    if amount < 1 or amount > 100: return await ctx.send("❌ 1–100")
    deleted = await ctx.channel.purge(limit=amount)
    await ctx.send(f"✅ Удалено: {len(deleted)}", delete_after=3)


@bot.command(name="giverole")
@commands.has_permissions(manage_roles=True)
async def giverole_cmd(ctx, member: discord.Member = None, role: discord.Role = None):
    if not member or not role: return await ctx.send("❌ .giverole @ @роль")
    try:
        await member.add_roles(role)
        await ctx.send(f"✅ {role.mention} → {member.mention}")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="takerole")
@commands.has_permissions(manage_roles=True)
async def takerole_cmd(ctx, member: discord.Member = None, role: discord.Role = None):
    if not member or not role: return await ctx.send("❌ .takerole @ @роль")
    try:
        await member.remove_roles(role)
        await ctx.send(f"✅ {role.mention} ← {member.mention}")
    except:
        await ctx.send("❌ Нет прав")


@bot.command(name="voicetop")
async def voicetop(ctx):
    now = datetime.now(timezone.utc)
    data = []
    for key, d in voice_tracker.items():
        if not key.startswith(str(ctx.guild.id)): continue
        total = d.get("total", 0)
        if "join_time" in d: total += (now - d["join_time"]).total_seconds()
        data.append((d.get("name", key), total))
    data.sort(key=lambda x: x[1], reverse=True)
    if not data: return await ctx.send("Нет данных.")
    lines = []
    for i, (name, sec) in enumerate(data[:10], 1):
        h, m = divmod(int(sec) // 60, 60)
        lines.append(f"{i}. {name} — {h}ч {m}м")
    await ctx.send(embed=discord.Embed(title="🎤 Топ", description="\n".join(lines), color=0x5865F2))


@bot.command(name="voiceinfo")
async def voiceinfo(ctx, member: discord.Member = None):
    member = member or ctx.author
    now = datetime.now(timezone.utc)
    key = f"{ctx.guild.id}_{member.id}"
    d = voice_tracker.get(key)
    if not d: return await ctx.send("❌ Нет данных.")
    total = d.get("total", 0)
    if "join_time" in d: total += (now - d["join_time"]).total_seconds()
    h, m = divmod(int(total) // 60, 60)
    await ctx.send(f"🎤 {member.mention}: {h}ч {m}м")


@bot.command(name="voicenow")
async def voicenow(ctx):
    now = datetime.now(timezone.utc)
    online = []
    for vc in ctx.guild.voice_channels:
        for member in vc.members:
            key = f"{ctx.guild.id}_{member.id}"
            d = voice_tracker.get(key, {})
            total = d.get("total", 0)
            if "join_time" in d: total += (now - d["join_time"]).total_seconds()
            h, m = divmod(int(total) // 60, 60)
            online.append(f"{member.mention} в {vc.name} — {h}ч {m}м")
    if not online: return await ctx.send("🔇 Пусто.")
    await ctx.send(embed=discord.Embed(title="🎤 Онлайн", description="\n".join(online), color=0x5865F2))


@bot.command(name="listall")
async def listall(ctx):
    if not await protection_check(ctx): return
    e = discord.Embed(title="📋 Настройки", color=0x5865F2)
    e.add_field(name="🛡️ Рейд", value="✅" if RAID_MODE else "❌")
    e.add_field(name="🔄 Бэкап", value="✅" if auto_backup_enabled else "❌")
    e.add_field(name="👋 Приветствия", value="✅" if WELCOME_ENABLED else "❌")
    e.add_field(name="✅ WL", value=str(len(WHITELIST_USERS)))
    e.add_field(name="⭐ Прота", value=str(len(PROTA_USERS)))
    e.add_field(name="🤖 Боты", value=str(len(WHITELIST_BOTS)))
    e.add_field(name="🔗 Каналы", value=str(len(ALLOWED_LINK_CHANNELS)))
    e.add_field(name="📊 Лог", value=f"<#{LOG_CHANNEL_ID}>" if LOG_CHANNEL_ID else "—")
    e.add_field(name="👋 Welcome", value=f"<#{WELCOME_CHANNEL_ID}>" if WELCOME_CHANNEL_ID else "—")
    e.add_field(name="🚨 Наказано", value=str(len(punished_nukers)))
    await ctx.send(embed=e)


if __name__ == "__main__":
    bot.run(TOKEN)